// Nebula presence server: tells clients which players currently run Nebula.
// No dependencies. Run:  node server.js     (PORT env var, default 8080)
// Works on any free Node host (Render, Railway, Fly.io, a VPS, ...). Put it behind HTTPS and paste the URL
// into Nebula > SETTINGS > "Nebula user server".
//
// GET /sync?me=<uuid>&ids=<uuid,uuid,...>
//   remembers <me> for 60 seconds and answers with the subset of <ids> that are remembered, as a JSON array.
// Nothing is written to disk. Anyone can claim any UUID, so treat the logo as decoration, not proof of identity.

const http = require('http');
const TTL = 60_000;
const UUID = /^[0-9a-f]{8}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{4}-?[0-9a-f]{12}$/i;
const seen = new Map();          // lower-case uuid -> last seen (ms)
const hits = new Map();          // ip -> [count, windowStart]

function limited(ip) {
  const now = Date.now();
  const h = hits.get(ip) || [0, now];
  if (now - h[1] > 60_000) { h[0] = 0; h[1] = now; }
  h[0]++;
  hits.set(ip, h);
  return h[0] > 30;              // 30 requests per minute per address (clients ask every 10 s)
}

setInterval(() => {
  const now = Date.now();
  for (const [k, t] of seen) if (now - t > TTL) seen.delete(k);
  for (const [k, h] of hits) if (now - h[1] > 120_000) hits.delete(k);
}, 30_000).unref();

http.createServer((req, res) => {
  const ip = req.headers['x-forwarded-for']?.split(',')[0].trim() || req.socket.remoteAddress;
  const url = new URL(req.url, 'http://localhost');
  if (url.pathname !== '/sync') { res.writeHead(200, { 'content-type': 'text/plain' }); return res.end('nebula presence ok'); }
  if (limited(ip)) { res.writeHead(429); return res.end('[]'); }

  const now = Date.now();
  const me = (url.searchParams.get('me') || '').toLowerCase();
  if (UUID.test(me)) seen.set(me, now);

  const ids = (url.searchParams.get('ids') || '').split(',').slice(0, 64)
    .map(s => s.trim().toLowerCase()).filter(s => UUID.test(s));
  const online = ids.filter(id => now - (seen.get(id) || 0) < TTL);

  res.writeHead(200, { 'content-type': 'application/json' });
  res.end(JSON.stringify(online));
}).listen(process.env.PORT || 8080, () => console.log('Nebula presence server running'));
