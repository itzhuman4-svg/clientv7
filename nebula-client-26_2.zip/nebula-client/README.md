# Nebula Client (Fabric, Minecraft 26.2)

Client-side mod by Orbitive. Needs JDK 25+, Fabric Loader 0.19.3+, Fabric API 0.156.0+26.2.

Build: `gradle build`. Jar: build/libs/nebula-client-1.0.0.jar (not -sources).

Keys: Right Shift = menu, C (hold) = zoom, Left Alt (hold) = freelook, B = add waypoint.
Menu tabs: MODS, PERFORMANCE (profiles + live usage), SETTINGS, WAYPOINTS. Profiles in the sidebar.

## What changed in this version
- **Saturation**: your hunger icons turn golden while you have saturation (the game's own hunger texture, recoloured). No saturation = the normal bar. The old HUD text and line were removed.
- **Potion effects**: the normal vanilla icon of every effect, level in the icon's top right corner, time left inside the icon along its bottom edge (turns yellow under 30 s and red under 10 s).
- **Nickname badge removed.** New module **Nametag & Logo**:
  - *Show my own name (F5)*: your name above your head in third person.
  - *Show logo beside names*: the Nebula logo (ringed planet) in front of your name.
  - *Mark other Nebula players*: logo in front of other players who use Nebula (needs the presence server below).
- **New logo** (ringed planet) for the mod icon, menu and name tags.
- **Optimizer** (module, on by default) and a stronger **PERFORMANCE** tab, see below.

## Optimizer: what it really does
Beyond changing video options, it:
1. skips particles that are far away or beyond a per-tick cap (mixin on the particle engine),
2. skips drawing far entities (never players, your mount or huge mobs like the dragon),
3. rebuilds HUD panels ~15 times a second instead of every frame (animations still run every frame),
4. caches the hitbox entity scan,
5. drops to ~15 FPS while the window is in the background and restores your limit when you come back,
6. optional: lowers render distance by 2 when your FPS stays under the target for 10 s and raises it again when there is room (never above your own setting).

The PERFORMANCE profiles (Potato / Low / Medium / High) set many more options (graphics mode, ambient occlusion, weather radius, anisotropic filtering, chunk fade, ...) and tighten the Optimizer distances. Options that do not exist in 26.2 are skipped silently.
A mod cannot change JVM flags, so the PERFORMANCE tab shows your GC and a tip (e.g. `-XX:+UseZGC -Xms4G -Xmx4G` in the launcher).

## Seeing the logo on other Nebula players
Minecraft servers do not pass custom data between players, so something both clients can reach is needed.
`presence-server/server.js` is a tiny Node script (no dependencies) that remembers which UUIDs said hello in the last minute.
1. Host it anywhere that runs Node (free tiers work) behind HTTPS.
2. Everyone who should see the logos pastes the same URL into **SETTINGS > Nebula user server**.
With no URL nothing is ever sent. With a URL the client sends your UUID and the UUIDs of players loaded around you every 10 s. Anyone can claim any UUID, so the logo is decoration, not proof.

## If something does not show
Mixins are optional: if the game changed a method, that feature turns off instead of crashing. Send `logs/latest.log` (search for `nebula` and `Mixin`) and I will fix it.
