package dev.nebula;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/**
 * Knowing which other players use Nebula needs something both clients can reach, because Minecraft servers do not pass
 * custom data between players. This talks to a tiny optional server (see presence-server/ in the project) that remembers
 * which UUIDs said hello in the last minute. With no URL set in SETTINGS nothing is ever sent.
 * What is sent: your UUID, and the UUIDs of players currently loaded around you (to ask which of them are Nebula users).
 */
final class Presence {
	private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
	private static volatile Set<String> online = Set.of();
	private static volatile boolean busy;
	private static int timer = 190;
	private static Object lastLevel;

	static boolean has(UUID id) { return online.contains(id.toString().toLowerCase(Locale.ROOT)); }

	static void tick(Minecraft mc) {
		if (mc.player == null || mc.level == null) {
			online = Set.of();
			lastLevel = null;
			return;
		}
		if (mc.level != lastLevel) { lastLevel = mc.level; timer = 190; }   // ask soon after joining
		Modules.Mod m = Modules.m("nametag");
		String base = Config.I.presenceUrl == null ? "" : Config.I.presenceUrl.trim();
		if (m == null || !m.on() || base.isEmpty() || busy) return;
		if (++timer < 200) return;                                           // every 10 seconds
		timer = 0;

		while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
		if (!base.startsWith("http://") && !base.startsWith("https://")) return;

		StringBuilder ids = new StringBuilder();
		if (m.flag("others")) {
			int n = 0;
			for (var p : mc.level.players()) {
				if (p == mc.player || n >= 60) continue;
				if (n++ > 0) ids.append(',');
				ids.append(p.getUUID());
			}
		}
		try {
			URI uri = URI.create(base + "/sync?me=" + mc.player.getUUID() + "&ids=" + ids);
			HttpRequest req = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(5)).header("User-Agent", "NebulaClient").GET().build();
			busy = true;
			HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).whenComplete((res, err) -> {
				try {
					if (err == null && res.statusCode() == 200) {
						Set<String> s = new HashSet<>();
						for (JsonElement e : JsonParser.parseString(res.body()).getAsJsonArray()) s.add(e.getAsString().toLowerCase(Locale.ROOT));
						online = s;
					}
				} catch (Throwable ignored) {
					// bad answer: keep the old list
				} finally {
					busy = false;
				}
			});
		} catch (Throwable t) {
			busy = false;
		}
	}

	private Presence() {}
}
