package dev.nebula;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Builds, lays out and draws every HUD element, the custom crosshair and the hit marker. */
public final class HudRenderer {
	private static final Map<String, Integer> CORNER = Map.ofEntries(
			Map.entry("fps", 0), Map.entry("cps", 0), Map.entry("ping", 0), Map.entry("tps", 0), Map.entry("speed", 0),
			Map.entry("playtime", 0), Map.entry("coords", 1), Map.entry("facing", 1), Map.entry("clock", 1),
			Map.entry("reach", 1), Map.entry("combo", 1), Map.entry("deathinfo", 1), Map.entry("waypoints", 1),
			Map.entry("keystrokes", 3), Map.entry("itemcounter", 3), Map.entry("armor", 3),
			Map.entry("effects", 2), Map.entry("inventory", 2),
			Map.entry("totems", 3), Map.entry("biome", 0), Map.entry("cpu", 0), Map.entry("memory", 0));
	private static final int GAP = 6, MARGIN = 4;
	private static final int[] CROSS_COLORS = {0xFFFFFFFF, 0xFF00E5FF, 0xFF55FF55, 0xFFFF5555, 0xFFFF7AC8, 0xFFFFE066};
	private static final int[] HIT_COLORS = {0xFFFFFF, 0x00E5FF, 0xFF4444, 0xFFE066};

	private static final ArrayDeque<Long> leftClicks = new ArrayDeque<>();
	private static final ArrayDeque<Long> rightClicks = new ArrayDeque<>();
	private static boolean prevL, prevR;

	abstract static class Panel {
		int w, h;
		boolean ownBg;
		abstract void draw(GuiGraphicsExtractor g, Minecraft mc, int x, int y, boolean bg);
	}

	record Item(String id, Panel panel, float x, float y, float w, float h, float scale) {}

	public static void register() {
		HudElementRegistry.attachElementBefore(VanillaHudElements.CHAT,
				Identifier.fromNamespaceAndPath("nebula", "hud"), HudRenderer::render);

		Object cross = Compat.staticField(VanillaHudElements.class, "CROSSHAIR");
		if (cross instanceof Identifier id) HudElementRegistry.replaceElement(id, orig -> (g, dt) -> crosshair(g, dt, orig));
		Object eff = Compat.staticField(VanillaHudElements.class, "STATUS_EFFECTS");
		if (eff instanceof Identifier id) HudElementRegistry.replaceElement(id, orig -> (g, dt) -> {
			if (!Modules.on("effects")) orig.extractRenderState(g, dt);
		});
	}

	private static void render(GuiGraphicsExtractor g, net.minecraft.client.DeltaTracker delta) {
		Minecraft mc = Minecraft.getInstance();
		Features.frame(mc);
		if (mc.player == null || mc.gui.hud.isHidden()) return;
		sampleClicks(mc);
		if (mc.gui.screen() instanceof HudEditScreen) return;
		WorldOverlay.draw(g, mc);
		saturationOverlay(g, mc);
		if (Modules.on("keystrokes")) animateKeys(new boolean[]{mc.options.keyUp.isDown(), mc.options.keyLeft.isDown(), mc.options.keyDown.isDown(),
				mc.options.keyRight.isDown(), mc.options.keyAttack.isDown(), mc.options.keyUse.isDown(), mc.options.keyJump.isDown()});
		drawItems(g, mc, cachedLayout(mc));
	}

	private static List<Item> cached;
	private static long cachedAt;
	private static int cachedW, cachedH;

	/** The Optimizer rebuilds the HUD panels about 15 times a second instead of every frame. Animations still run every frame. */
	private static List<Item> cachedLayout(Minecraft mc) {
		long now = System.nanoTime();
		int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
		if (cached == null || !Optimizer.hudCache() || sw != cachedW || sh != cachedH || now - cachedAt > 66_000_000L) {
			cached = layout(mc, false);
			cachedAt = now;
			cachedW = sw;
			cachedH = sh;
		}
		return cached;
	}

	private static void sampleClicks(Minecraft mc) {
		boolean l = mc.gui.screen() == null && mc.options.keyAttack.isDown();
		boolean r = mc.gui.screen() == null && mc.options.keyUse.isDown();
		long now = System.currentTimeMillis();
		if (l && !prevL) leftClicks.add(now);
		if (r && !prevR) rightClicks.add(now);
		prevL = l;
		prevR = r;
		while (!leftClicks.isEmpty() && now - leftClicks.peek() > 1000) leftClicks.poll();
		while (!rightClicks.isEmpty() && now - rightClicks.peek() > 1000) rightClicks.poll();
	}

	// ------------------------------------------------------------ crosshair + hit marker

	private static void crosshair(GuiGraphicsExtractor g, net.minecraft.client.DeltaTracker dt, HudElement orig) {
		Minecraft mc = Minecraft.getInstance();
		if (Modules.on("crosshair")) drawCrosshair(g, mc); else orig.extractRenderState(g, dt);
		if (Modules.on("hitindicator") && Stats.hitTicks > 0) drawHitMarker(g, mc);
	}

	private static void drawCrosshair(GuiGraphicsExtractor g, Minecraft mc) {
		Modules.Mod m = Modules.m("crosshair");
		int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
		int s = (int) m.num("size"), gp = (int) m.num("gap"), t = (int) m.num("thickness");
		int color = CROSS_COLORS[Math.floorMod(m.opt("color"), CROSS_COLORS.length)];
		if (m.opt("style") == 5) { drawCustom(g, cx, cy); return; }
		List<int[]> r = new ArrayList<>();
		int ht = t / 2;
		switch (m.opt("style")) {
			case 1 -> { int q = Math.max(t, 2); r.add(new int[]{cx - q / 2, cy - q / 2, cx - q / 2 + q, cy - q / 2 + q}); }
			case 2 -> {
				r.add(new int[]{cx - s, cy - ht, cx + s, cy - ht + t});
				r.add(new int[]{cx - ht, cy - s, cx - ht + t, cy + s});
			}
			case 3 -> {
				int rad = Math.max(3, s);
				for (int a = 0; a < 360; a += 10) {
					int px = cx + (int) Math.round(rad * Math.cos(Math.toRadians(a)));
					int py = cy + (int) Math.round(rad * Math.sin(Math.toRadians(a)));
					r.add(new int[]{px, py, px + t, py + t});
				}
			}
			case 4 -> {
				r.add(new int[]{cx - s, cy - s, cx + s, cy - s + t});
				r.add(new int[]{cx - s, cy + s - t, cx + s, cy + s});
				r.add(new int[]{cx - s, cy - s, cx - s + t, cy + s});
				r.add(new int[]{cx + s - t, cy - s, cx + s, cy + s});
			}
			default -> {
				r.add(new int[]{cx - gp - s, cy - ht, cx - gp, cy - ht + t});
				r.add(new int[]{cx + gp, cy - ht, cx + gp + s, cy - ht + t});
				r.add(new int[]{cx - ht, cy - gp - s, cx - ht + t, cy - gp});
				r.add(new int[]{cx - ht, cy + gp, cx - ht + t, cy + gp + s});
			}
		}
		if (m.flag("outline")) for (int[] q : r) g.fill(q[0] - 1, q[1] - 1, q[2] + 1, q[3] + 1, 0xFF000000);
		for (int[] q : r) g.fill(q[0], q[1], q[2], q[3], color);
	}

	static final int[] PAL = {0, 0xFFFFFFFF, 0xFF00E5FF, 0xFF55FF55, 0xFFFF5555, 0xFFFF7AC8, 0xFFFFE066, 0xFF000000, 0xFFFF9A3C};

	private static void drawCustom(GuiGraphicsExtractor g, int cx, int cy) {
		String c = Config.I.customCrosshair;
		if (c == null || c.length() != 225) c = CrosshairEditorScreen.preset(0);
		for (int j = 0; j < 15; j++) {
			int i = 0;
			while (i < 15) {
				int v = c.charAt(j * 15 + i) - '0';
				if (v <= 0 || v >= PAL.length) { i++; continue; }
				int k = i;
				while (k + 1 < 15 && c.charAt(j * 15 + k + 1) - '0' == v) k++;
				g.fill(cx - 7 + i, cy - 7 + j, cx - 7 + k + 1, cy - 6 + j, PAL[v]);
				i = k + 1;
			}
		}
	}

	private static void drawHitMarker(GuiGraphicsExtractor g, Minecraft mc) {
		Modules.Mod m = Modules.m("hitindicator");
		int cx = mc.getWindow().getGuiScaledWidth() / 2, cy = mc.getWindow().getGuiScaledHeight() / 2;
		int size = (int) m.num("size"), gap = 3;
		int alpha = Mth.clamp((int) (255f * Stats.hitTicks / Stats.hitMax), 40, 255);
		int color = (alpha << 24) | HIT_COLORS[Math.floorMod(m.opt("color"), HIT_COLORS.length)];
		for (int i = gap; i < gap + size; i++) {
			g.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
			g.fill(cx - i - 1, cy + i, cx - i, cy + i + 1, color);
			g.fill(cx + i, cy - i - 1, cx + i + 1, cy - i, color);
			g.fill(cx - i - 1, cy - i - 1, cx - i, cy - i, color);
		}
	}

	// ------------------------------------------------------------ layout / draw

	static List<Item> layout(Minecraft mc, boolean edit) {
		int sw = mc.getWindow().getGuiScaledWidth();
		int sh = mc.getWindow().getGuiScaledHeight();
		int[] cur = {MARGIN, MARGIN, sh - MARGIN, sh - MARGIN};
		List<Item> out = new ArrayList<>();

		for (Modules.Mod m : Modules.ALL) {
			if (!m.hud || !m.on()) continue;
			String id = m.id;
			Config.P cfg = Config.I.p(id);
			Panel panel = build(id, mc);
			if (panel == null && edit) panel = text(mc, List.of(m.name));
			if (panel == null || panel.h == 0) continue;

			float s = Mth.clamp(cfg.scale, 0.5f, 3f);
			float w = panel.w * s, h = panel.h * s;
			float x, y;
			if (cfg.x != null && cfg.y != null) {
				x = (float) (cfg.x * sw);
				y = (float) (cfg.y * sh);
			} else if (id.equals("armor") && m.opt("layout") == 0) {
				x = sw / 2f - 91 - 6 - w;   // just left of the hotbar
				y = sh - 1 - h;
			} else {
				int c = CORNER.getOrDefault(id, 0);
				x = (c % 2 == 0) ? MARGIN + 2 : sw - MARGIN - 2 - w;
				if (c < 2) { y = cur[c] + 2; cur[c] += (int) h + GAP + 4; }
				else { y = cur[c] - h - 2; cur[c] -= (int) h + GAP + 4; }
			}
			x = Math.round(Mth.clamp(x, 0, Math.max(0, sw - w)));
			y = Math.round(Mth.clamp(y, 0, Math.max(0, sh - h)));
			out.add(new Item(id, panel, x, y, w, h, s));
		}
		return out;
	}

	static void drawItems(GuiGraphicsExtractor g, Minecraft mc, List<Item> items) {
		for (Item it : items) {
			boolean bg = Config.I.allBg && Config.I.p(it.id()).bg;
			var pose = g.pose();
			pose.pushMatrix();
			pose.translate(it.x(), it.y());
			pose.scale(it.scale(), it.scale());
			if (bg && !it.panel().ownBg) g.fill(-2, -2, it.panel().w + 2, it.panel().h + 2, 0x88000000);
			it.panel().draw(g, mc, 0, 0, bg);
			pose.popMatrix();
		}
	}

	// ------------------------------------------------------------ panels

	private static Panel build(String id, Minecraft mc) {
		return switch (id) {
			case "fps" -> text(mc, List.of("FPS: " + mc.getFps()));
			case "cps" -> cps(mc);
			case "ping" -> text(mc, List.of("Ping: " + ping(mc) + " ms"));
			case "coords" -> coords(mc);
			case "facing" -> text(mc, List.of("Facing: " + facing(mc)));
			case "tps" -> text(mc, List.of(String.format("TPS: %.1f", Stats.tps)));
			case "speed" -> speed();
			case "playtime" -> playtime();
			case "deathinfo" -> deathInfo(mc);
			case "clock" -> clock();
			case "reach" -> reach();
			case "combo" -> text(mc, List.of("Combo: " + Stats.combo));
			case "waypoints" -> waypoints(mc);
			case "keystrokes" -> keystrokes(mc);
			case "armor" -> armor(mc);
			case "effects" -> effects(mc);
			case "inventory" -> inventory(mc);
			case "itemcounter" -> itemCounter(mc);
			case "totems" -> totems(mc);
			case "biome" -> biome(mc);
			case "cpu" -> text(mc, List.of(Perf.cpuProc < 0 ? "CPU: n/a" : "CPU: " + Math.round(Perf.cpuProc * 100) + "%"));
			case "memory" -> text(mc, List.of(Modules.m("memory").opt("unit") == 1
					? "RAM: " + (Perf.usedMb() * 100 / Math.max(1, Perf.maxMb())) + "%"
					: "RAM: " + Perf.usedMb() + "/" + Perf.maxMb() + " MB"));
			default -> null;
		};
	}

	private static int ping(Minecraft mc) {
		try {
			var conn = mc.getConnection();
			if (conn == null) return 0;
			var info = conn.getPlayerInfo(mc.player.getUUID());
			return info == null ? 0 : info.getLatency();
		} catch (Throwable t) {
			return 0;
		}
	}

	private static Panel text(Minecraft mc, List<String> lines) {
		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft m, int x, int y, boolean bg) {
				for (int i = 0; i < lines.size(); i++) Ui.text(g, lines.get(i), x, y + i * 10, 0xFFFFFFFF);
			}
		};
		int max = 0;
		for (String s : lines) max = Math.max(max, Ui.width(s));
		p.w = max;
		p.h = lines.size() * 10 - 1;
		return p;
	}

	private static Panel cps(Minecraft mc) {
		String s = "CPS: " + leftClicks.size();
		if (Modules.m("cps").flag("right")) s += " | " + rightClicks.size();
		return text(mc, List.of(s));
	}

	private static Panel coords(Minecraft mc) {
		var pl = mc.player;
		String s = Modules.m("coords").flag("decimals")
				? String.format("Coordinates: %.1f %.1f %.1f", pl.getX(), pl.getY(), pl.getZ())
				: "Coordinates: " + (int) Math.floor(pl.getX()) + " " + (int) Math.floor(pl.getY()) + " " + (int) Math.floor(pl.getZ());
		return text(mc, List.of(s));
	}

	private static final String[] DIRS = {"South", "Southwest", "West", "Northwest", "North", "Northeast", "East", "Southeast"};
	private static final String[] DIRS_SHORT = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

	private static String facing(Minecraft mc) {
		float yaw = ((Mth.wrapDegrees(mc.player.getYRot()) % 360) + 360) % 360;
		return DIRS[Math.round(yaw / 45f) % 8];
	}

	private static Panel speed() {
		Modules.Mod m = Modules.m("speed");
		double v = Stats.speed * (m.opt("unit") == 1 ? 3.6 : 1);
		return text(Minecraft.getInstance(), List.of(String.format("Speed: %.1f %s", v, m.opt("unit") == 1 ? "km/h" : "b/s")));
	}

	private static String dur(long sec) {
		return sec >= 3600 ? (sec / 3600) + "h " + ((sec / 60) % 60) + "m" : (sec / 60) + "m " + String.format("%02d", sec % 60) + "s";
	}

	private static Panel playtime() {
		List<String> l = new ArrayList<>();
		l.add("Session: " + dur(Stats.sessionSeconds()));
		if (Modules.m("playtime").flag("total")) l.add("Total: " + dur((long) Config.I.totalPlaySeconds));
		return text(Minecraft.getInstance(), l);
	}

	private static Panel deathInfo(Minecraft mc) {
		if (Config.I.deaths == 0) return text(mc, List.of("Deaths: 0"));
		return text(mc, List.of("Deaths: " + Config.I.deaths, "Last death: " + Config.I.lastDeath));
	}

	private static Panel clock() {
		Modules.Mod m = Modules.m("clock");
		boolean h12 = m.opt("format") == 0, sec = m.flag("seconds");
		String pat = h12 ? (sec ? "h:mm:ss a" : "h:mm a") : (sec ? "HH:mm:ss" : "HH:mm");
		String s = LocalTime.now().format(DateTimeFormatter.ofPattern(pat));
		return text(Minecraft.getInstance(), List.of(h12 ? s.toLowerCase() : s));
	}

	private static Panel reach() {
		int d = (int) Modules.m("reach").num("decimals");
		String v = Stats.lastReach < 0 ? "-" : String.format("%." + d + "f", Stats.lastReach);
		return text(Minecraft.getInstance(), List.of("Reach: " + v));
	}

	private static Panel waypoints(Minecraft mc) {
		if (Config.I.waypoints.isEmpty() || !Modules.m("waypoints").flag("list")) return null;
		int max = (int) Modules.m("waypoints").num("max");
		List<String> lines = new ArrayList<>();
		var pl = mc.player;
		for (Config.Waypoint w : Config.I.waypoints) {
			if (lines.size() >= max) break;
			double dx = w.x - pl.getX(), dz = w.z - pl.getZ();
			double dist = Math.sqrt(dx * dx + dz * dz);
			double yawTo = ((Math.toDegrees(Math.atan2(-dx, dz)) % 360) + 360) % 360;
			lines.add(w.name + " " + (int) dist + "m " + DIRS_SHORT[(int) Math.round(yawTo / 45) % 8]);
		}
		return text(mc, lines);
	}

	// ---- slot style (framed slots like the armor / effect screenshots)

	private static void slot(GuiGraphicsExtractor g, int x, int y, int fill, int border) {
		g.fill(x, y, x + 20, y + 20, fill);
		g.fill(x, y, x + 20, y + 1, border);
		g.fill(x, y + 19, x + 20, y + 20, border);
		g.fill(x, y, x + 1, y + 20, border);
		g.fill(x + 19, y, x + 20, y + 20, border);
	}

	private static void small(GuiGraphicsExtractor g, Minecraft mc, String s, float right, float bottom, int color, float sc) {
		var pose = g.pose();
		pose.pushMatrix();
		pose.translate(right - Ui.width(s) * sc, bottom - 8 * sc);
		pose.scale(sc, sc);
		Ui.text(g, s, 0, 0, color);
		pose.popMatrix();
	}

	private static Panel armor(Minecraft mc) {
		Modules.Mod m = Modules.m("armor");
		boolean horiz = m.opt("layout") == 0, pct = m.opt("mode") == 1;
		EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND};
		List<ItemStack> stacks = new ArrayList<>();
		for (int i = 0; i < slots.length; i++) {
			if (i == 4 && !m.flag("held")) break;
			ItemStack st = mc.player.getItemBySlot(slots[i]);
			if (!st.isEmpty()) stacks.add(st);
		}
		if (stacks.isEmpty()) return null;

		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				for (int i = 0; i < stacks.size(); i++) {
					ItemStack st = stacks.get(i);
					int sx = horiz ? x + i * 22 : x, sy = horiz ? y : y + i * 22;
					slot(g, sx, sy, 0xCC0C1118, st.isDamageableItem() ? durBorder(st) : 0xFF2A3A4F);
					g.item(st, sx + 2, sy + 2);
					small(g, mm, numLabel(st, pct), sx + 19, sy + 19, 0xFFFFFFFF, 0.8f);
				}
			}
		};
		int n = stacks.size();
		p.w = horiz ? n * 22 - 2 : 20;
		p.h = horiz ? 20 : n * 22 - 2;
		p.ownBg = true;
		return p;
	}

	private static String numLabel(ItemStack st, boolean pct) {
		if (!st.isDamageableItem()) return st.getCount() > 1 ? String.valueOf(st.getCount()) : "";
		int left = st.getMaxDamage() - st.getDamageValue();
		return pct ? Math.round(100f * left / st.getMaxDamage()) + "%" : String.valueOf(left);
	}

	private static int durBorder(ItemStack st) {
		float f = 1f - (float) st.getDamageValue() / st.getMaxDamage();
		return f > 0.5f ? 0xFF1F6E8C : f > 0.2f ? 0xFF9A8420 : 0xFF9A2A2A;
	}

	private static String roman(int n) {
		return switch (n) { case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n); };
	}

	private static String effectTime(MobEffectInstance e) {
		if (e.isInfiniteDuration()) return "inf";
		int sec = e.getDuration() / 20;
		return sec >= 3600 ? (sec / 3600) + "h" : String.format("%d:%02d", sec / 60, sec % 60);
	}

	/** Small text with a drop shadow, left edge at x, top edge at y, scaled. */
	private static void tiny(GuiGraphicsExtractor g, Minecraft mc, String s, float x, float y, int color, float sc) {
		var pose = g.pose();
		pose.pushMatrix();
		pose.translate(x, y);
		pose.scale(sc, sc);
		Ui.text(g, s, 1, 1, 0xFF000000);
		Ui.text(g, s, 0, 0, color);
		pose.popMatrix();
	}

	/**
	 * Effects: the normal vanilla icon of each effect in a framed slot, the level in the top right corner of the icon
	 * and the time left inside the icon along its bottom edge.
	 */
	private static Panel effects(Minecraft mc) {
		Modules.Mod m = Modules.m("effects");
		boolean horiz = m.opt("layout") == 1, timer = m.flag("timer");
		List<MobEffectInstance> list = new ArrayList<>(mc.player.getActiveEffects());
		if (list.isEmpty()) return null;
		final int cell = 22;
		final Icons.Img[] icons = new Icons.Img[list.size()];
		for (int i = 0; i < icons.length; i++) icons[i] = Icons.effect(list.get(i).getEffect().getRegisteredName());

		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				for (int i = 0; i < list.size(); i++) {
					MobEffectInstance e = list.get(i);
					int sx = horiz ? x + i * cell : x, sy = horiz ? y : y + i * cell;
					int rgb = e.getEffect().value().getColor() & 0xFFFFFF;
					slot(g, sx, sy, 0xCC0C1118, 0xFF000000 | rgb);
					int ix = sx + 1, iy = sy + 1;
					if (icons[i].empty()) {
						g.fill(ix, iy, ix + 18, iy + 18, (0x66 << 24) | rgb);
						String name = e.getEffect().value().getDisplayName().getString();
						String abbr = name.length() > 2 ? name.substring(0, 2).toUpperCase() : name.toUpperCase();
						Ui.text(g, abbr, ix + 9 - Ui.width(abbr) / 2, iy + 4, 0xFFFFFFFF);
					} else {
						Icons.draw(g, icons[i], ix, iy, 18);
					}
					if (e.getAmplifier() > 0) {
						String r = roman(e.getAmplifier() + 1);
						tiny(g, mm, r, ix + 18 - Ui.width(r) * 0.6f - 1, iy, 0xFFFFE066, 0.6f);
					}
					if (timer) {
						String t = effectTime(e);
						int sec = e.getDuration() / 20;
						int col = e.isInfiniteDuration() ? 0xFFFFFFFF : sec <= 10 ? 0xFFFF5555 : sec <= 30 ? 0xFFFFD866 : 0xFFFFFFFF;
						g.fill(ix, iy + 12, ix + 18, iy + 18, 0x99000000);
						tiny(g, mm, t, ix + 9 - Ui.width(t) * 0.6f / 2f, iy + 12.4f, col, 0.6f);
					}
				}
			}
		};
		int n = list.size();
		p.w = horiz ? n * cell - 2 : 20;
		p.h = horiz ? 20 : n * cell - 2;
		p.ownBg = true;
		return p;
	}

	private static Panel inventory(Minecraft mc) {
		Inventory inv = mc.player.getInventory();
		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				for (int i = 0; i < 27; i++) {
					int sx = x + (i % 9) * 18, sy = y + (i / 9) * 18;
					g.fill(sx, sy, sx + 17, sy + 17, 0x88101820);
					ItemStack st = inv.getItem(9 + i);
					if (!st.isEmpty()) {
						g.item(st, sx + 1, sy + 1);
						g.itemDecorations(mm.font, st, sx + 1, sy + 1);
					}
				}
			}
		};
		p.w = 9 * 18 - 1;
		p.h = 3 * 18 - 1;
		p.ownBg = true;
		return p;
	}

	/**
	 * Saturation: every hunger icon that is covered by your saturation turns golden (drawn over the vanilla icon,
	 * using the game's own hunger texture recoloured). No saturation = nothing is drawn and the bar stays vanilla.
	 */
	private static void saturationOverlay(GuiGraphicsExtractor g, Minecraft mc) {
		if (!Modules.on("saturation")) return;
		var p = mc.player;
		if (p.isCreative() || p.isSpectator() || p.getVehicle() instanceof LivingEntity) return;
		var fd = p.getFoodData();
		float sat = Math.min(fd.getSaturationLevel(), fd.getFoodLevel());
		if (sat < 0.5f) return;
		Icons.Img full = Icons.goldFood(false), half = Icons.goldFood(true);
		int sw = mc.getWindow().getGuiScaledWidth(), sh = mc.getWindow().getGuiScaledHeight();
		for (int i = 0; i < 10; i++) {
			float f = sat - 2 * i;
			if (f < 0.5f) break;
			Icons.draw(g, f >= 1.5f ? full : half, sw / 2 + 82 - i * 8, sh - 39, 9);
		}
	}

	private static Panel totems(Minecraft mc) {
		Inventory inv = mc.player.getInventory();
		int n = 0;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack st = inv.getItem(i);
			if (st.is(Items.TOTEM_OF_UNDYING)) n += st.getCount();
		}
		final String label = "x" + n;
		final ItemStack icon = new ItemStack(Items.TOTEM_OF_UNDYING);
		final int count = n;
		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				g.item(icon, x, y);
				Ui.text(g, label, x + 20, y + 4, count == 0 ? 0xFFFF6B6B : 0xFFFFFFFF);
			}
		};
		p.w = 20 + Ui.width(label);
		p.h = 16;
		return p;
	}

	private static Panel biome(Minecraft mc) {
		String name = "?";
		try {
			String r = mc.level.getBiome(mc.player.blockPosition()).getRegisteredName();
			int c = r.indexOf(':');
			StringBuilder sb = new StringBuilder();
			for (String w : (c >= 0 ? r.substring(c + 1) : r).split("_")) {
				if (w.isEmpty()) continue;
				sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
			}
			name = sb.toString().trim();
		} catch (Throwable ignored) { }
		return text(mc, List.of("Biome: " + name));
	}

	private static Panel itemCounter(Minecraft mc) {
		ItemStack held = mc.player.getMainHandItem();
		if (held.isEmpty()) return null;
		Inventory inv = mc.player.getInventory();
		int total = 0;
		for (int i = 0; i < inv.getContainerSize(); i++) {
			ItemStack st = inv.getItem(i);
			if (ItemStack.isSameItem(st, held)) total += st.getCount();
		}
		final String label = "x" + total;
		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				g.item(held, x, y);
				Ui.text(g, label, x + 20, y + 4, 0xFFFFFFFF);
			}
		};
		p.w = 20 + Ui.width(label);
		p.h = 16;
		return p;
	}

	// pressed colours are translucent, like the reference: white by default
	private static final int[] PRESSED = {0xC000C8E8, 0xB8FFFFFF, 0xC04CE06A, 0xC0FF6FB5, 0xC0FFA03C};
	private static final float[] keyAnim = new float[7];
	private static long lastKeyNs;

	private record K(int x, int y, int w, int h, String label, int idx) {}

	/** Keys fade smoothly: ~120 ms to light up, ~200 ms to fade out. */
	private static void animateKeys(boolean[] down) {
		long ns = System.nanoTime();
		float dt = lastKeyNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastKeyNs) / 1e9f);
		lastKeyNs = ns;
		for (int i = 0; i < keyAnim.length; i++) {
			float t = down[i] ? 1f : 0f;
			keyAnim[i] += (t - keyAnim[i]) * (1f - (float) Math.exp(-dt / (down[i] ? 0.045f : 0.07f)));
			if (Math.abs(t - keyAnim[i]) < 0.005f) keyAnim[i] = t;
		}
	}

	private static Panel keystrokes(Minecraft mc) {
		Modules.Mod m = Modules.m("keystrokes");
		var o = mc.options;
		boolean mouse = m.flag("mouse"), space = m.flag("space");
		int pressed = PRESSED[Math.floorMod(m.opt("color"), PRESSED.length)];
		String cl = "L " + leftClicks.size(), cr = "R " + rightClicks.size();

		List<K> keys = new ArrayList<>();
		keys.add(new K(19, 0, 18, 18, "W", 0));
		keys.add(new K(0, 19, 18, 18, "A", 1));
		keys.add(new K(19, 19, 18, 18, "S", 2));
		keys.add(new K(38, 19, 18, 18, "D", 3));
		int ny = 38;
		if (mouse) {
			keys.add(new K(0, ny, 27, 18, cl, 4));
			keys.add(new K(28, ny, 28, 18, cr, 5));
			ny += 19;
		}
		final int spaceY = ny;

		Panel p = new Panel() {
			@Override void draw(GuiGraphicsExtractor g, Minecraft mm, int x, int y, boolean bg) {
				int idle = bg ? 0x73000000 : (pressed & 0x00FFFFFF);
				for (K k : keys) g.fill(x + k.x(), y + k.y(), x + k.x() + k.w(), y + k.y() + k.h(), Ui.lerpArgb(idle, pressed, keyAnim[k.idx()]));
				if (space) g.fill(x, y + spaceY, x + 56, y + spaceY + 10, Ui.lerpArgb(idle, pressed, keyAnim[6]));
				for (K k : keys) {
					int tx = x + k.x() + (k.w() - Ui.width(k.label())) / 2;
					Ui.text(g, k.label(), tx, y + k.y() + (k.h() - 8) / 2, Ui.lerpArgb(0xFFFFFFFF, 0xFF10161E, keyAnim[k.idx()]));
				}
				if (space) g.fill(x + 16, y + spaceY + 4, x + 40, y + spaceY + 5, Ui.lerpArgb(0xFFFFFFFF, 0xFF10161E, keyAnim[6]));
			}
		};
		p.w = 56;
		p.h = ny - 1 + (space ? 11 : 0);
		p.ownBg = true;
		return p;
	}

	private HudRenderer() {}
}
