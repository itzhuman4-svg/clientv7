package dev.nebula;

import net.minecraft.client.OptionInstance;

import java.lang.reflect.Field;

/**
 * Vanilla's OptionInstance#set() rejects values outside the slider range (FOV < 30, gamma > 1).
 * We write the backing field directly so zoom and fullbright can go past those limits.
 */
final class Opt {
	private static Field valueField;

	static <T> void force(OptionInstance<T> opt, T value) {
		try {
			if (valueField == null) {
				valueField = OptionInstance.class.getDeclaredField("value");
				valueField.setAccessible(true);
			}
			valueField.set(opt, value);
		} catch (Throwable t) {
			NebulaClient.LOG.warn("Reflection failed, falling back to set()", t);
			opt.set(value);
		}
	}

	private Opt() {}
}
