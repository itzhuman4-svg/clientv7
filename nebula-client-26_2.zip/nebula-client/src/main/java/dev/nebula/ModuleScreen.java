package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Per-module options window, styled like the main window. */
final class ModuleScreen extends UiScreen {
	private final Modules.Mod mod;

	ModuleScreen(String id) {
		super("Module");
		this.mod = Modules.m(id);
	}

	private static String fmt(double v, double step) { return step >= 1 ? String.valueOf((int) Math.round(v)) : String.format("%.1f", v); }

	@Override
	void draw(GuiGraphicsExtractor g, Minecraft mc) {
		int W = Math.min(400, width - 20), H = Math.min(332, height - 16);
		int x = (width - W) / 2, y = (height - H) / 2;
		Ui.rect(g, x - 1, y - 1, W + 2, H + 2, 0xFF0E0F11);
		Ui.rect(g, x, y, W, H, 0xF21F2125);
		Ui.rect(g, x, y, W, 34, Ui.TOP);
		Ui.rect(g, x, y + 34, W, 1, 0xFF111316);

		if (button(g, "<", x + 8, y + 9, 16, 16, false)) mc.gui.setScreen(new NebulaScreen());
		Ui.spaced(g, mod.name.toUpperCase(), x + 32, y + 13, 0xFFFFFFFF);
		boolean on = mod.on();
		if (gbtn(g, on ? "ENABLED" : "DISABLED", x + W - 88, y + 9, 80, 16, on ? 1 : 2)) mod.setOn(!on);

		int rw = W - 28, x0 = x + 14, yy = y + 46;
		yy += 10 * Ui.wrap(g, mod.desc, x0, yy, rw, Ui.DIM, 2) + 10;
		Ui.rect(g, x0, yy - 5, rw, 1, 0xFF3B3F46);

		for (Modules.Setting s : mod.settings) {
			Ui.text(g, s.label(), x0, yy + 6, Ui.TEXT);
			switch (s.type()) {
				case 'T' -> {
					boolean v = mod.flag(s.key());
					if (gbtn(g, v ? "ON" : "OFF", x0 + rw - 70, yy, 70, 18, v ? 1 : 2)) mod.setFlag(s.key(), !v);
				}
				case 'S' -> {
					double v = mod.num(s.key());
					double nv = slider(g, mod.id + "." + s.key(), x0 + rw - 200, yy, 140, 18, v, s.min(), s.max(), s.step());
					if (nv != v) mod.setNum(s.key(), nv);
					Ui.text(g, fmt(nv, s.step()), x0 + rw - 52, yy + 5, Ui.CYAN);
				}
				case 'C' -> {
					int n = s.opts().length;
					int i = Math.floorMod(mod.opt(s.key()), n);
					if (gbtn(g, s.opts()[i].toUpperCase(), x0 + rw - 200, yy, 200, 18, 0)) mod.setNum(s.key(), (i + 1) % n);
				}
				default -> { }
			}
			yy += 26;
		}

		if (mod.id.equals("crosshair")) {
			if (gbtn(g, "EDIT CUSTOM CROSSHAIR", x0, yy, rw, 18, 3)) mc.gui.setScreen(new CrosshairEditorScreen());
			yy += 28;
		}
		if (mod.id.equals("waypoints")) {
			if (gbtn(g, "OPEN WAYPOINT MANAGER", x0, yy, rw, 18, 3)) NebulaScreen.open(mc, 3);
			yy += 28;
		}

		if (mod.hud) {
			Config.P p = Config.I.p(mod.id);
			Ui.rect(g, x0, yy - 3, rw, 1, 0xFF3B3F46);
			yy += 6;
			Ui.text(g, "Background", x0, yy + 6, Ui.TEXT);
			if (gbtn(g, p.bg ? "ON" : "OFF", x0 + rw - 70, yy, 70, 18, p.bg ? 1 : 2)) p.bg = !p.bg;
			yy += 26;
			Ui.text(g, "Size", x0, yy + 6, Ui.TEXT);
			double nv = slider(g, mod.id + ".scale", x0 + rw - 200, yy, 140, 18, p.scale, 0.5, 3, 0.1);
			p.scale = (float) nv;
			Ui.text(g, String.format("%.1fx", nv), x0 + rw - 52, yy + 5, Ui.CYAN);
			yy += 26;
			Ui.text(g, "Move it with EDIT HUD LAYOUT in the main window.", x0, yy + 2, 0xFF6C727C);
		}
	}
}
