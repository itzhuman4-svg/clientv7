package dev.nebula.mixin;

import dev.nebula.Freelook;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Freelook: while active, mouse movement turns the camera instead of the player. */
@Mixin(Entity.class)
public abstract class EntityMixin {
	@Inject(method = "turn", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$turn(double yRot, double xRot, CallbackInfo ci) {
		if ((Object) this != Minecraft.getInstance().player) return;
		Freelook.turnHookSeen = true;
		if (Freelook.active) {
			Freelook.turn(yRot, xRot);
			ci.cancel();
		}
	}
}
