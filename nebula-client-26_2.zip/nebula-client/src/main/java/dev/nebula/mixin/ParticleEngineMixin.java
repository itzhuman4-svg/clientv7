package dev.nebula.mixin;

import dev.nebula.Optimizer;
import net.minecraft.client.particle.Particle;
import net.minecraft.core.particles.ParticleOptions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Optimizer: far-away particles and floods of particles in one tick are never created. */
@Mixin(targets = "net.minecraft.client.particle.ParticleEngine")
public abstract class ParticleEngineMixin {
	@Inject(method = "createParticle", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$limit(ParticleOptions options, double x, double y, double z, double vx, double vy, double vz, CallbackInfoReturnable<Particle> cir) {
		if (Optimizer.dropParticle(x, y, z)) cir.setReturnValue(null);
	}
}
