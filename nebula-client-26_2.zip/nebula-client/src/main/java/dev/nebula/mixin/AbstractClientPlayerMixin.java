package dev.nebula.mixin;

import dev.nebula.Cosmetics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.core.ClientAsset;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.player.PlayerSkin;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Swaps the cape texture on YOUR OWN skin so the equipped Nebula cape renders in third person. */
@Mixin(AbstractClientPlayer.class)
public abstract class AbstractClientPlayerMixin {
	@Inject(method = "getSkin", at = @At("RETURN"), cancellable = true, require = 0)
	private void nebula$cape(CallbackInfoReturnable<PlayerSkin> cir) {
		if ((Object) this != Minecraft.getInstance().player) return;
		Identifier cape = Cosmetics.capeTexture();
		if (cape == null) return;
		PlayerSkin s = cir.getReturnValue();
		cir.setReturnValue(new PlayerSkin(s.body(), new ClientAsset.ResourceTexture(cape), s.elytra(), s.model(), s.secure()));
	}
}
