package dev.nebula.mixin;

import dev.nebula.Modules;
import net.minecraft.client.Minecraft;
import net.minecraft.world.level.Level;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Weather Changer: your client reports your chosen weather. The server is not affected. */
@Mixin(Level.class)
public abstract class WeatherMixin {
	@Inject(method = "getRainLevel", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$rain(float partial, CallbackInfoReturnable<Float> cir) {
		Modules.Mod w = Modules.m("weather");
		if (w == null || !w.on() || (Object) this != Minecraft.getInstance().level) return;
		cir.setReturnValue(w.opt("weather") >= 1 ? 1f : 0f);
	}

	@Inject(method = "getThunderLevel", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$thunder(float partial, CallbackInfoReturnable<Float> cir) {
		Modules.Mod w = Modules.m("weather");
		if (w == null || !w.on() || (Object) this != Minecraft.getInstance().level) return;
		cir.setReturnValue(w.opt("weather") >= 2 ? 1f : 0f);
	}
}
