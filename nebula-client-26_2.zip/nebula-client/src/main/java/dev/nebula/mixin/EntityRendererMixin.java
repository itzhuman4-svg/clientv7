package dev.nebula.mixin;

import dev.nebula.Nametags;
import dev.nebula.Optimizer;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.state.EntityRenderState;
import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Name tags: shows your own name in F5 and adds the Nebula logo.
 * Optimizer: skips drawing entities that are far away.
 * Both injections are optional (require = 0), so a different signature in a future version just turns them off.
 */
@Mixin(targets = "net.minecraft.client.renderer.entity.EntityRenderer")
public abstract class EntityRendererMixin {
	@Inject(method = "extractRenderState", at = @At("TAIL"), require = 0)
	private void nebula$nametag(Entity entity, EntityRenderState state, float partial, CallbackInfo ci) {
		Nametags.apply(entity, state, partial);
	}

	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$cull(Entity entity, Frustum frustum, double camX, double camY, double camZ, CallbackInfoReturnable<Boolean> cir) {
		if (Optimizer.cullEntity(entity, camX, camY, camZ)) cir.setReturnValue(false);
	}
}
