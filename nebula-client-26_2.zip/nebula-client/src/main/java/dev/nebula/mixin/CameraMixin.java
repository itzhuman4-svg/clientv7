package dev.nebula.mixin;

import dev.nebula.Freelook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Freelook: the camera uses its own yaw/pitch while freelook is active. Skipped silently if the method is missing. */
@Mixin(targets = "net.minecraft.client.Camera")
public abstract class CameraMixin {
	@ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 0)
	private float nebula$yaw(float v) {
		Freelook.cameraHookSeen = true;
		return Freelook.active ? Freelook.camYaw() : v;
	}

	@ModifyVariable(method = "setRotation", at = @At("HEAD"), argsOnly = true, ordinal = 1, require = 0)
	private float nebula$pitch(float v) {
		return Freelook.active ? Freelook.camPitch() : v;
	}
}
