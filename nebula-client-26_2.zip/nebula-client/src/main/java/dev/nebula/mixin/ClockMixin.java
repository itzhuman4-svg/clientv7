package dev.nebula.mixin;

import dev.nebula.Modules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Time Changer: the client clock reports your chosen time. Only changes what YOU see. */
@Mixin(targets = {"net.minecraft.client.multiplayer.ClientClockManager", "net.minecraft.client.clock.ClientClockManager",
		"net.minecraft.client.ClientClockManager", "net.minecraft.world.clock.ClientClockManager"})
public abstract class ClockMixin {
	private static final long[] PRESETS = {1000, 6000, 12000, 13000, 18000, 23000};

	@Inject(method = "getTotalTicks", at = @At("HEAD"), cancellable = true, require = 0)
	private void nebula$time(CallbackInfoReturnable<Long> cir) {
		Modules.Mod t = Modules.m("time");
		if (t == null || !t.on()) return;
		int i = t.opt("preset");
		cir.setReturnValue(i >= PRESETS.length ? (long) t.num("custom") : PRESETS[i]);
	}
}
