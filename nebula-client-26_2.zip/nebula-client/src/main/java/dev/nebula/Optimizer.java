package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;

/**
 * Work that actually saves frames, beyond changing video options:
 * - drops particles that are far away or beyond a per-tick cap (mixin on the particle engine)
 * - skips rendering far-away entities (mixin on the entity renderer)
 * - caches the HUD layout (see HudRenderer)
 * - drops the frame rate while the window is in the background
 * - can lower / raise render distance on its own to hold a target FPS
 * The selected performance profile tightens the distances.
 */
public final class Optimizer {
	// per profile: Potato, Low, Medium, High
	private static final int[] PDIST = {20, 28, 40, 64};
	private static final int[] PCAP = {120, 200, 400, 1000};
	private static final int[] EDIST = {32, 48, 72, 128};

	public static long particlesCulled, entitiesCulled;
	private static int particlesThisTick;

	private static boolean throttling;
	private static Object throttleOpt, savedLimit;
	private static int throttleTick;

	private static int origRd = -1, adaptTimer, fpsN;
	private static double fpsAcc;

	private static Modules.Mod mod() { return Modules.m("optimizer"); }

	public static boolean on() {
		Modules.Mod m = mod();
		return m != null && m.on();
	}

	static boolean hudCache() {
		Modules.Mod m = mod();
		return m != null && m.on() && m.flag("hudcache");
	}

	private static double limit(double slider, int[] table) {
		int lv = Config.I.perfProfile;
		return lv >= 0 && lv < table.length ? Math.min(slider, table[lv]) : slider;
	}

	// ------------------------------------------------------------ called from mixins

	/** True if this particle should not be created. */
	public static boolean dropParticle(double x, double y, double z) {
		Modules.Mod m = mod();
		if (m == null || !m.on() || !m.flag("particles")) return false;
		var p = Minecraft.getInstance().player;
		if (p == null) return false;
		double d = limit(m.num("pdist"), PDIST);
		int lv = Config.I.perfProfile;
		int cap = lv >= 0 && lv < PCAP.length ? PCAP[lv] : 400;
		if (p.distanceToSqr(x, y, z) > d * d || ++particlesThisTick > cap) {
			particlesCulled++;
			return true;
		}
		return false;
	}

	/** True if this entity is too far away to be worth drawing. Players, your mount and huge mobs are never hidden. */
	public static boolean cullEntity(Entity e, double camX, double camY, double camZ) {
		Modules.Mod m = mod();
		if (m == null || !m.on() || !m.flag("entities")) return false;
		if (e instanceof Player || e.getBbWidth() > 2.5f) return false;
		var me = Minecraft.getInstance().player;
		if (me == null || e == me || e == me.getVehicle()) return false;
		double d = limit(m.num("edist"), EDIST);
		if (e instanceof ItemEntity || e instanceof ExperienceOrb) d *= 0.6;
		if (e.distanceToSqr(camX, camY, camZ) > d * d) {
			entitiesCulled++;
			return true;
		}
		return false;
	}

	// ------------------------------------------------------------ per tick

	static void tick(Minecraft mc) {
		particlesThisTick = 0;
		Modules.Mod m = mod();
		boolean on = m != null && m.on();
		background(mc, on && m.flag("background"));
		adaptive(mc, on && m.flag("adaptive"), m);
	}

	private static void background(Minecraft mc, boolean want) {
		boolean idle = want && mc.player != null && !mc.isWindowActive();
		if (idle) {
			if (!throttling) {
				Object opt = Compat.invoke(mc.options, "framerateLimit");
				if (opt == Compat.FAIL || opt == null) return;
				Object cur = Compat.invoke(opt, "get");
				if (!(cur instanceof Integer)) return;
				throttleOpt = opt;
				savedLimit = cur;
				throttling = true;
				throttleTick = 0;
				Compat.invoke(opt, "set", 15);
			} else if (++throttleTick % 40 == 0) {
				Compat.invoke(throttleOpt, "set", 15);
			}
		} else if (throttling) {
			Compat.invoke(throttleOpt, "set", savedLimit);
			throttling = false;
		}
	}

	private static int renderDistance(Minecraft mc) {
		Object opt = Compat.invoke(mc.options, "renderDistance");
		if (opt == Compat.FAIL || opt == null) return -1;
		return Compat.invoke(opt, "get") instanceof Integer i ? i : -1;
	}

	private static void setRenderDistance(Minecraft mc, int v) {
		Object opt = Compat.invoke(mc.options, "renderDistance");
		if (opt != Compat.FAIL && opt != null) Compat.invoke(opt, "set", v);
	}

	/** Every 10 seconds: too slow -> 2 chunks less, comfortably fast -> 2 chunks more (never above your own setting). */
	private static void adaptive(Minecraft mc, boolean want, Modules.Mod m) {
		if (!want) {
			if (origRd >= 0) { setRenderDistance(mc, origRd); origRd = -1; }
			adaptTimer = 0; fpsN = 0; fpsAcc = 0;
			return;
		}
		if (mc.player == null || mc.level == null || mc.gui.screen() != null) return;
		fpsAcc += mc.getFps();
		fpsN++;
		if (++adaptTimer < 200) return;
		double avg = fpsAcc / Math.max(1, fpsN);
		adaptTimer = 0; fpsAcc = 0; fpsN = 0;

		int cur = renderDistance(mc);
		if (cur <= 0) return;
		if (origRd < 0) origRd = cur;
		double target = m.num("target");
		if (avg < target * 0.85 && cur > 6) setRenderDistance(mc, Math.max(6, cur - 2));
		else if (avg > target * 1.35 && cur < origRd) setRenderDistance(mc, Math.min(origRd, cur + 2));
	}

	/** Forget remembered values (a performance profile just changed the same options). */
	static void forget() { origRd = -1; }

	/** Puts temporary changes back so options.txt never saves them. */
	static void restore(Minecraft mc) {
		if (throttling) { Compat.invoke(throttleOpt, "set", savedLimit); throttling = false; }
		if (origRd >= 0) { setRenderDistance(mc, origRd); origRd = -1; }
	}

	static int currentRenderDistance(Minecraft mc) { return renderDistance(mc); }

	private Optimizer() {}
}
