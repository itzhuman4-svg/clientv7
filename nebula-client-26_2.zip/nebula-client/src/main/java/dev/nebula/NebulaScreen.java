package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

import java.util.ArrayList;
import java.util.List;

/** Main window (Right Shift): MODS / SETTINGS / WAYPOINTS tabs with a profile sidebar. */
public class NebulaScreen extends UiScreen {
	private static final String[] TABS = {"MODS", "PERFORMANCE", "SETTINGS", "WAYPOINTS"};
	private static final int[] TAB_W = {58, 98, 74, 86};
	private static final String[] FILTERS = {"ALL", "PVP", "VISUAL", "INFO", "QOL"};
	private static final int[] CAT_COLOR = {0xFF5B8CFF, 0xFF00C8F0, 0xFF8C99B3, 0xFF58C98A};
	private static int tab = 0, filter = 0;
	/** Smooth scrolling in pixels: *T is where the wheel wants to be, *Y is what is drawn (eases toward it). */
	private static float scrollT, scrollY, wpT, wpY;
	private static float tabFade = 1f;
	private static String search = "";

	private String renaming, renameBuf = "", flash;
	private long flashUntil;
	private boolean confirmReset;
	private int pickFor = -1, maxScroll;

	public NebulaScreen() { super("Nebula Client"); Icons.clear(); }

	static void open(Minecraft mc, int t) { tab = t; mc.gui.setScreen(new NebulaScreen()); }

	private void switchTab(int i) {
		if (tab != i) tabFade = 0f;
		tab = i; scrollT = 0; scrollY = 0; wpT = 0; wpY = 0; renaming = null; pickFor = -1; confirmReset = false;
	}

	private void say(String s) { flash = s; flashUntil = System.currentTimeMillis() + 3000; }

	@Override
	protected void onScroll(int dir) {
		if (tab == 0) scrollT = Math.max(0, Math.min(maxScroll, scrollT + dir * 46));
		else if (tab == 3) wpT = Math.max(0, Math.min(maxScroll, wpT + dir * 36));
	}

	@Override
	void draw(GuiGraphicsExtractor g, Minecraft mc) {
		Config.I.ensureDefault();
		float ease = 1f - (float) Math.exp(-dt * 16f);
		scrollY += (scrollT - scrollY) * ease;
		if (Math.abs(scrollT - scrollY) < 0.4f) scrollY = scrollT;
		wpY += (wpT - wpY) * ease;
		if (Math.abs(wpT - wpY) < 0.4f) wpY = wpT;
		int W = Math.min(540, width - 20), H = Math.min(344, height - 16);
		int x = (width - W) / 2, y = (height - H) / 2;

		Ui.rect(g, x - 1, y - 1, W + 2, H + 2, 0xFF0E0F11);
		Ui.rect(g, x, y, W, H, 0xF21F2125);

		// title bar
		Ui.rect(g, x, y, W, 34, Ui.TOP);
		Ui.rect(g, x, y + 34, W, 1, 0xFF111316);
		Previews.drawRaw(g, "logo", x + 7, y + 7);
		Ui.spaced(g, "NEBULA", x + 33, y + 13, 0xFFFFFFFF);
		Ui.text(g, "CLIENT", x + 33 + Ui.spacedWidth("NEBULA") + 5, y + 13, Ui.DIM);

		float tf = Math.min(1f, (W - 128 - 34) / 330f);
		int tx = x + 128;
		for (int i = 0; i < TABS.length; i++) {
			int tw = (int) (TAB_W[i] * tf);
			if (gbtn(g, TABS[i], tx, y + 9, tw, 16, tab == i ? 3 : 4)) switchTab(i);
			tx += tw + 4;
		}
		if (button(g, "x", x + W - 24, y + 9, 16, 16, false)) onClose();

		sidebar(g, mc, x, y, W, H);

		int cx0 = x + 130, cw = W - 130 - 8, cy0 = y + 42;
		switch (tab) {
			case 0 -> modsTab(g, mc, cx0, cy0, cw, y + H - 8);
			case 1 -> perfTab(g, mc, cx0, cy0, cw, y + H - 8);
			case 2 -> settingsTab(g, mc, cx0, cy0, cw);
			default -> waypointsTab(g, mc, cx0, cy0, cw, y + H - 8);
		}

		// smooth transition: content fades in from the window colour after a tab/filter change
		tabFade = Math.min(1f, tabFade + dt / 0.22f);
		float e = 1f - (1f - tabFade) * (1f - tabFade) * (1f - tabFade);
		int fa = (int) ((1f - e) * 255);
		if (fa > 3) Ui.rect(g, cx0 - 3, cy0 - 3, cw + 6, y + H - cy0 - 2, (fa << 24) | 0x1F2125);
		if (flash != null && System.currentTimeMillis() < flashUntil)
			Ui.text(g, flash, cx0, y + H - 14, Ui.CYAN);
	}

	// ------------------------------------------------------------ sidebar (profiles)

	private void sidebar(GuiGraphicsExtractor g, Minecraft mc, int x, int y, int W, int H) {
		int sx = x + 7, sy = y + 42, sw = 116;
		Ui.rect(g, x + 4, y + 38, 122, H - 42, 0xFF1B1D21);

		List<String> names = new ArrayList<>(Config.I.profiles.keySet());
		int bottomH = 4 * 19 + 4;
		int rows = Math.max(1, (H - 42 - bottomH - 6) / 17);
		for (int i = 0; i < names.size() && i < rows; i++) {
			String n = names.get(i);
			int ry = sy + i * 17;
			boolean act = n.equals(Config.I.activeProfile), hover = Ui.hit(mx, my, sx, ry, sw, 15);
			float ha = hv("p:" + n, hover);
			Ui.rect(g, sx, ry, sw, 15, act ? Ui.lerpArgb(0xFF3A3F47, 0xFF454B54, ha) : Ui.lerpArgb(0xFF282B30, 0xFF343840, ha));
			if (act) Ui.rect(g, sx, ry, 2, 15, 0xFF5C9BFF);

			if (n.equals(renaming)) {
				renameBuf = textField(g, "rename", sx, ry, sw, 15, renameBuf, 18, "Name");
				if (!"rename".equals(focusId)) { Config.I.rename(renaming, renameBuf); renaming = null; }
			} else {
				Ui.text(g, Ui.fit(n, sw - 38), sx + 6, ry + 4, act ? 0xFFFFFFFF : Ui.TEXT);
				boolean hp = Ui.hit(mx, my, sx + sw - 27, ry, 13, 15), hx = Ui.hit(mx, my, sx + sw - 13, ry, 13, 15);
				Ui.pencil(g, sx + sw - 24, ry + 4, hp ? 0xFFFFFFFF : 0xFF9AA0AA);
				Ui.text(g, "x", sx + sw - 10, ry + 4, hx ? 0xFFFF6B6B : 0xFF9AA0AA);
				if (click) {
					if (hp) { renaming = n; renameBuf = n; focusId = "rename"; }
					else if (hx) { Config.I.delete(n); say("Deleted " + n); }
					else if (hover) { Config.I.switchTo(n); say("Switched to " + n); }
				}
			}
		}

		int by = y + H - 8 - 4 * 19 + 3;
		if (gbtn(g, "SAVE AS NEW", sx, by, sw, 16, 0)) { Config.I.saveAsNew(); say("Saved as " + Config.I.activeProfile); }
		if (gbtn(g, "COPY PROFILE", sx, by + 19, sw, 16, 0)) {
			Compat.invoke(mc.keyboardHandler, "setClipboard", Config.I.export());
			say("Profile copied. Paste it to share.");
		}
		if (gbtn(g, "IMPORT PROFILE", sx, by + 38, sw, 16, 0)) {
			Object c = Compat.invoke(mc.keyboardHandler, "getClipboard");
			say(c instanceof String s && Config.I.importFrom(s) ? "Profile imported" : "Clipboard has no Nebula profile");
		}
		if (gbtn(g, "EDIT HUD LAYOUT", sx, by + 57, sw, 16, 3)) mc.gui.setScreen(new HudEditScreen());
	}

	// ------------------------------------------------------------ MODS

	private void modsTab(GuiGraphicsExtractor g, Minecraft mc, int cx0, int cy0, int cw, int bottom) {
		int[] fw = {34, 36, 50, 38, 36};
		int fx = cx0;
		for (int i = 0; i < FILTERS.length; i++) {
			if (gbtn(g, FILTERS[i], fx, cy0, fw[i], 16, filter == i ? 3 : 4)) { if (filter != i) tabFade = 0f; filter = i; scrollT = 0; }
			fx += fw[i] + 3;
		}
		int sfx = fx + 6, sfw = cx0 + cw - sfx;
		if (sfw > 50) {
			String ns = textField(g, "search", sfx, cy0, sfw, 16, search, 20, "Search...");
			if (!ns.equals(search)) { search = ns; scrollT = 0; }
		}

		List<Modules.Mod> list = new ArrayList<>();
		for (Modules.Mod m : Modules.ALL) {
			if (filter > 0 && !m.cat.equals(Modules.CATS[filter - 1])) continue;
			if (!search.isEmpty() && !m.name.toLowerCase().contains(search.toLowerCase())) continue;
			list.add(m);
		}
		if (list.isEmpty()) { Ui.text(g, "No modules match your search.", cx0, cy0 + 30, Ui.DIM); return; }

		int gy = cy0 + 22, areaH = bottom - gy, gap = 6, ch = 100, stride = ch + gap;
		int total = (list.size() + 2) / 3;
		int contentH = total * stride - gap;
		maxScroll = Math.max(0, contentH - areaH);
		scrollT = Math.max(0, Math.min(maxScroll, scrollT));
		scrollY = Math.max(0, Math.min(maxScroll, scrollY));
		boolean bar = contentH > areaH;
		int gw = cw - (bar ? 14 : 0);
		int cwid = (gw - 2 * gap) / 3;
		int off = Math.round(scrollY);
		int firstRow = Math.max(0, off / stride), lastRow = Math.min(total - 1, (off + areaH) / stride);

		// cards are clipped to the list area while they slide; the mouse only counts inside it
		boolean clipped = scissorOn(g, cx0 - 2, gy, cx0 + gw + 2, bottom);
		int realMy = my;
		if (my < gy || my >= bottom) my = -10000;
		for (int idx = firstRow * 3; idx < Math.min(list.size(), (lastRow + 1) * 3); idx++) {
			Modules.Mod m = list.get(idx);
			int cx = cx0 + (idx % 3) * (cwid + gap), cy = gy + (idx / 3) * stride - off;
			if (!clipped && (cy < gy || cy + ch > bottom)) continue;
			boolean on = m.on(), hover = Ui.hit(mx, my, cx, cy, cwid, ch);
			float ha = hv("c:" + m.id, hover);
			Ui.rect(g, cx, cy, cwid, ch, Ui.lerpArgb(0xFF2B2E33, 0xFF33373D, ha));
			Ui.border(g, cx, cy, cwid, ch, Ui.lerpArgb(0xFF3B3F46, 0xFF6C7380, ha));

			float onA = hv("on:" + m.id, on);
			if (onA > 0.01f) {
				int hh = ch / 2 + 6;
				for (int r = 0; r < hh; r++) {
					float f = 1f - r / (float) hh;
					int al = (int) (110 * onA * f * f);
					if (al >= 2) Ui.rect(g, cx + 1, cy + ch - 2 - r, cwid - 2, 1, (al << 24) | 0x4DB8FF);
				}
			}

			int catIdx = 0;
			for (int c = 0; c < Modules.CATS.length; c++) if (Modules.CATS[c].equals(m.cat)) catIdx = c;
			int ix = cx + cwid / 2 - 14, iy = cy + 8;
			Ui.rect(g, ix, iy, 28, 28, on ? CAT_COLOR[catIdx] : 0xFF4A4E56);
			Ui.border(g, ix, iy, 28, 28, 0xFF000000);
			String letter = m.name.substring(0, 1).toUpperCase();
			var pose = g.pose();
			pose.pushMatrix();
			pose.translate(ix + 14 - Ui.width(letter), iy + 14 - 8);
			pose.scale(2f, 2f);
			Ui.text(g, letter, 0, 0, on ? 0xFF0A1016 : 0xFF9AA0AA);
			pose.popMatrix();

			Ui.center(g, Ui.fit(m.name, cwid - 8), cx + cwid / 2, cy + 44, on ? Ui.TEXT : Ui.DIM);
			boolean hasOpts = !m.settings.isEmpty() || m.hud;
			if (gbtn(g, hasOpts ? "OPTIONS" : "NO OPTIONS", cx + 6, cy + 58, cwid - 12, 16, hasOpts ? 0 : 4) && hasOpts)
				mc.gui.setScreen(new ModuleScreen(m.id));
			if (gbtn(g, on ? "ENABLED" : "DISABLED", cx + 6, cy + 78, cwid - 12, 16, on ? 1 : 2)) m.setOn(!on);
		}
		my = realMy;
		if (clipped) scissorOff(g);

		if (bar) {
			int bx = cx0 + cw - 12;
			if (gbtn(g, "^", bx, gy, 12, 16, 0)) onScroll(-1);
			if (gbtn(g, "v", bx, gy + areaH - 16, 12, 16, 0)) onScroll(1);
			int trackY = gy + 20, trackH = areaH - 40;
			Ui.rect(g, bx + 4, trackY, 4, trackH, 0xFF1B1D21);
			int th = Math.max(14, trackH * areaH / contentH);
			int ty = trackY + Math.round((trackH - th) * scrollY / Math.max(1, maxScroll));
			Ui.rect(g, bx + 4, ty, 4, th, 0xFF5C9BFF);
		}
	}

	// ------------------------------------------------------------ PERFORMANCE

	private static void bar(GuiGraphicsExtractor g, int x, int y, int w, int h, double frac, int color) {
		Ui.rect(g, x, y, w, h, 0xFF15171A);
		Ui.border(g, x, y, w, h, 0xFF3B3F46);
		int fw = (int) ((w - 2) * Math.max(0, Math.min(1, frac)));
		Ui.rect(g, x + 1, y + 1, fw, h - 2, color);
	}

	private static int usageColor(double f) { return f < 0.6 ? 0xFF58C98A : f < 0.85 ? 0xFFE0B341 : 0xFFE0524A; }

	private void perfTab(GuiGraphicsExtractor g, Minecraft mc, int cx0, int cy0, int cw, int bottom) {
		Ui.spaced(g, "PERFORMANCE PROFILE", cx0, cy0 + 1, Ui.DIM);
		int bw = (cw - 12) / 4;
		for (int i = 0; i < 4; i++)
			if (gbtn(g, Perf.NAMES[i], cx0 + i * (bw + 4), cy0 + 14, bw, 18, Config.I.perfProfile == i ? 3 : 0)) {
				Perf.apply(mc, i);
				say("Applied " + Perf.NAMES[i] + " profile");
			}
		String d = Config.I.perfProfile >= 0 ? Perf.DESC[Config.I.perfProfile]
				: "Pick a profile to set render distance, particles, clouds and more in one click.";
		int y = cy0 + 38 + 10 * Ui.wrap(g, d, cx0, cy0 + 38, cw, Ui.DIM, 3) + 8;
		Ui.rect(g, cx0, y - 4, cw, 1, 0xFF3B3F46);

		int fps = mc.getFps();
		Ui.text(g, "FPS " + fps + "    avg " + (int) Perf.avgFps() + "    1% low " + (int) Perf.lowFps()
				+ "    frame " + (fps > 0 ? 1000 / fps : 0) + " ms", cx0, y, Ui.TEXT);
		y += 14;

		double mem = Perf.usedMb() / (double) Math.max(1, Perf.maxMb());
		Ui.text(g, "Game memory  " + Perf.usedMb() + " / " + Perf.maxMb() + " MB", cx0, y, Ui.TEXT);
		bar(g, cx0, y + 11, cw, 7, mem, usageColor(mem));
		y += 24;

		if (Perf.cpuProc >= 0) {
			Ui.text(g, "Game CPU  " + Math.round(Perf.cpuProc * 100) + "%", cx0, y, Ui.TEXT);
			bar(g, cx0, y + 11, cw / 2 - 4, 7, Perf.cpuProc, usageColor(Perf.cpuProc));
		} else Ui.text(g, "Game CPU  not available", cx0, y, Ui.DIM);
		if (Perf.cpuSys >= 0) {
			Ui.text(g, "System CPU  " + Math.round(Perf.cpuSys * 100) + "%", cx0 + cw / 2 + 4, y, Ui.TEXT);
			bar(g, cx0 + cw / 2 + 4, y + 11, cw / 2 - 4, 7, Perf.cpuSys, usageColor(Perf.cpuSys));
		}
		y += 24;

		long tot = Perf.sysTotalMb(), free = Perf.sysFreeMb();
		if (tot > 0 && free >= 0) {
			double f = (tot - free) / (double) tot;
			Ui.text(g, "System RAM  " + (tot - free) + " / " + tot + " MB", cx0, y, Ui.TEXT);
			bar(g, cx0, y + 11, cw, 7, f, usageColor(f));
			y += 24;
		}

		boolean opt = Optimizer.on();
		String os = "Optimizer " + (opt ? "ON" : "OFF") + "   particles skipped " + Optimizer.particlesCulled
				+ "   entities skipped " + Optimizer.entitiesCulled + "   render dist " + Optimizer.currentRenderDistance(mc);
		Ui.text(g, Ui.fit(os, cw), cx0, y, opt ? Ui.TEXT : Ui.DIM);
		y += 12;
		Ui.text(g, Ui.fit("GC: " + Perf.gcName() + "   " + Perf.jvmTip(), cw), cx0, y, Ui.DIM);
		y += 14;
		if (gbtn(g, "OPTIMIZER OPTIONS", cx0, y, 150, 16, 3)) mc.gui.setScreen(new ModuleScreen("optimizer"));
		y += 22;

		int gh = bottom - y - 4;
		if (gh >= 28 && Perf.histCount > 1) {
			gh = Math.min(gh, 50);
			Ui.rect(g, cx0, y, cw, gh, 0xFF15171A);
			Ui.border(g, cx0, y, cw, gh, 0xFF3B3F46);
			int max = Perf.maxFps(), step = Math.max(1, (cw - 2) / Perf.hist.length);
			for (int i = 0; i < Perf.histCount; i++) {
				int hgt = Math.max(1, (int) ((gh - 2) * (Perf.sample(i) / (double) max)));
				Ui.rect(g, cx0 + 1 + i * step, y + gh - 1 - hgt, step, hgt, 0xFF3D7BE0);
			}
			Ui.text(g, "FPS history (last 6s, peak " + max + ")", cx0 + 4, y + 3, Ui.DIM);
		}
	}

	// ------------------------------------------------------------ SETTINGS

	private void settingsTab(GuiGraphicsExtractor g, Minecraft mc, int cx0, int cy0, int cw) {
		int y = cy0;
		Ui.text(g, "All HUD backgrounds", cx0, y + 6, Ui.TEXT);
		if (gbtn(g, Config.I.allBg ? "ON" : "OFF", cx0 + cw - 70, y, 70, 18, Config.I.allBg ? 1 : 2)) Config.I.allBg = !Config.I.allBg;
		y += 30;
		Ui.text(g, "Reset current profile", cx0, y + 6, Ui.TEXT);
		if (gbtn(g, confirmReset ? "CONFIRM" : "RESET", cx0 + cw - 90, y, 90, 18, 2)) {
			if (confirmReset) { Config.I.resetCurrent(); say("Profile reset to defaults"); confirmReset = false; }
			else confirmReset = true;
		}
		y += 30;
		Ui.text(g, "Nebula user server (optional, shows the logo on other Nebula players)", cx0, y, Ui.TEXT);
		y += 12;
		String cur = Config.I.presenceUrl == null ? "" : Config.I.presenceUrl;
		String nu = textField(g, "presence", cx0, y, cw, 16, cur, 120, "https://your-server.example   (empty = offline)");
		if (!nu.equals(cur)) Config.I.presenceUrl = nu;
		y += 28;
		Ui.rect(g, cx0, y - 8, cw, 1, 0xFF3B3F46);
		Ui.text(g, "Active profile: " + Config.I.activeProfile, cx0, y, Ui.TEXT);
		y += 14;
		long ps = (long) Config.I.totalPlaySeconds;
		Ui.text(g, "Total playtime: " + (ps / 3600) + "h " + ((ps / 60) % 60) + "m", cx0, y, Ui.DIM);
		y += 14;
		Ui.text(g, "Deaths recorded: " + Config.I.deaths, cx0, y, Ui.DIM);
		y += 22;
		Ui.wrap(g, "Keys: Right Shift = menu, C = zoom (hold), Left Alt = freelook (hold), B = add waypoint. Rebind them in Controls.", cx0, y, cw, Ui.DIM, 3);
		y += 36;
		Ui.wrap(g, "Background blur follows Options > Video Settings > Menu Background Blur.", cx0, y, cw, 0xFF6C727C, 2);
	}

	// ------------------------------------------------------------ WAYPOINTS

	private void waypointsTab(GuiGraphicsExtractor g, Minecraft mc, int cx0, int cy0, int cw, int bottom) {
		if (gbtn(g, "ADD WAYPOINT HERE", cx0, cy0, 150, 16, 3)) {
			if (mc.player != null) { WorldOverlay.addHere(mc); say("Waypoint added"); } else say("Join a world first");
		}
		Ui.text(g, "or press B in game", cx0 + 158, cy0 + 4, Ui.DIM);

		List<Config.Waypoint> ws = Config.I.waypoints;
		if (ws.isEmpty()) { Ui.text(g, "No waypoints yet.", cx0, cy0 + 30, Ui.DIM); return; }

		int ly = cy0 + 24, rowH = 24, areaH = bottom - ly;
		maxScroll = Math.max(0, ws.size() * rowH - areaH);
		wpT = Math.max(0, Math.min(maxScroll, wpT));
		wpY = Math.max(0, Math.min(maxScroll, wpY));
		int woff = Math.round(wpY);
		boolean wclip = scissorOn(g, cx0 - 1, ly, cx0 + cw + 1, bottom);
		int realMy = my;
		if (my < ly || my >= bottom) my = -10000;
		int remove = -1, pickRow = -1;
		boolean coords = cw > 330;

		for (int i = Math.max(0, woff / rowH); i < Math.min(ws.size(), (woff + areaH) / rowH + 1); i++) {
			Config.Waypoint w = ws.get(i);
			int ry = ly + i * rowH - woff;
			if (!wclip && (ry < ly || ry + rowH > bottom)) continue;
			Ui.rect(g, cx0, ry, cw, rowH - 2, 0xFF2B2E33);
			Ui.border(g, cx0, ry, cw, rowH - 2, 0xFF3B3F46);

			int col = w.color >= 0 ? w.color : Ui.SWATCH[i % Ui.SWATCH.length];
			boolean hs = Ui.hit(mx, my, cx0 + 5, ry + 4, 14, 14);
			Ui.rect(g, cx0 + 5, ry + 4, 14, 14, 0xFF000000 | col);
			Ui.border(g, cx0 + 5, ry + 4, 14, 14, hs ? 0xFFFFFFFF : 0xFF000000);
			if (click && hs) pickFor = pickFor == i ? -1 : i;
			if (pickFor == i) pickRow = ry;

			w.name = textField(g, "wp" + i, cx0 + 26, ry + 3, 118, 16, w.name, 16, "Name");
			int rx = cx0 + 150;
			if (coords) {
				Ui.text(g, Ui.fit((int) w.x + " " + (int) w.y + " " + (int) w.z, cw - 150 - 62), rx, ry + 8, Ui.DIM);
			}
			if (gbtn(g, "DELETE", cx0 + cw - 56, ry + 3, 52, 16, 2)) remove = i;
		}
		my = realMy;
		if (wclip) scissorOff(g);

		if (pickFor >= 0 && pickRow >= 0) {
			int px = cx0 + 26, py = pickRow + rowH - 2;
			int pw = Ui.SWATCH.length * 16 + 6;
			Ui.rect(g, px - 2, py, pw, 22, 0xFF15171A);
			Ui.border(g, px - 2, py, pw, 22, 0xFF5A606A);
			for (int c = 0; c < Ui.SWATCH.length; c++) {
				int sx = px + c * 16 + 1;
				boolean h = Ui.hit(mx, my, sx, py + 4, 14, 14);
				Ui.rect(g, sx, py + 4, 14, 14, 0xFF000000 | Ui.SWATCH[c]);
				Ui.border(g, sx, py + 4, 14, 14, h ? 0xFFFFFFFF : 0xFF000000);
				if (click && h && pickFor < ws.size()) { ws.get(pickFor).color = Ui.SWATCH[c]; pickFor = -1; }
			}
			if (click && !Ui.hit(mx, my, px - 2, py, pw, 22) && pickRow >= 0 && !Ui.hit(mx, my, cx0 + 5, pickRow + 4, 14, 14)) pickFor = -1;
		}
		if (remove >= 0) { ws.remove(remove); pickFor = -1; Config.save(); }
	}

	/** Starts clipping drawing to a rectangle. Returns false if this game version has no such method (rows then pop in whole). */
	private static boolean scissorOn(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2) {
		return Compat.invoke(g, "enableScissor", x1, y1, x2, y2) != Compat.FAIL;
	}

	private static void scissorOff(GuiGraphicsExtractor g) { Compat.invoke(g, "disableScissor"); }
}
