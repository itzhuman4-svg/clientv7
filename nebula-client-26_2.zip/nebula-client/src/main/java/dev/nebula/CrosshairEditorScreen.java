package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;

/** Draw your own 15x15 crosshair pixel by pixel. */
final class CrosshairEditorScreen extends UiScreen {
	private static final int N = 15, CELL = 12;
	private static final String[] COLOR_NAMES = {"Eraser", "White", "Cyan", "Green", "Red", "Pink", "Yellow", "Black", "Orange"};
	private static final String[] PRESETS = {"Cross", "Dot", "Plus", "Ring", "Dot + Cross"};

	private final char[] cells;
	private int color = 1;

	CrosshairEditorScreen() {
		super("Crosshair Editor");
		String s = Config.I.customCrosshair;
		cells = (s != null && s.length() == N * N ? s : preset(0)).toCharArray();
	}

	static String preset(int k) {
		char[] c = new char[N * N];
		java.util.Arrays.fill(c, '0');
		for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
			int dx = i - 7, dy = j - 7;
			double d = Math.sqrt(dx * dx + dy * dy);
			boolean on = switch (k) {
				case 0 -> (dx == 0 && Math.abs(dy) >= 2 && Math.abs(dy) <= 5) || (dy == 0 && Math.abs(dx) >= 2 && Math.abs(dx) <= 5);
				case 1 -> Math.abs(dx) <= 1 && Math.abs(dy) <= 1;
				case 2 -> (dx == 0 && Math.abs(dy) <= 6) || (dy == 0 && Math.abs(dx) <= 6);
				case 3 -> d >= 4.4 && d <= 5.4;
				default -> (dx == 0 && dy == 0) || (dx == 0 && Math.abs(dy) >= 3 && Math.abs(dy) <= 6) || (dy == 0 && Math.abs(dx) >= 3 && Math.abs(dx) <= 6);
			};
			if (on) c[j * N + i] = '1';
		}
		return new String(c);
	}

	private void save() { Config.I.customCrosshair = new String(cells); }

	@Override
	void draw(GuiGraphicsExtractor g, Minecraft mc) {
		int W = Math.min(470, width - 20), H = Math.min(300, height - 16);
		int x = (width - W) / 2, y = (height - H) / 2;
		Ui.rect(g, x - 1, y - 1, W + 2, H + 2, 0xFF0E0F11);
		Ui.rect(g, x, y, W, H, 0xF21F2125);
		Ui.rect(g, x, y, W, 34, Ui.TOP);
		Ui.rect(g, x, y + 34, W, 1, 0xFF111316);
		if (button(g, "<", x + 8, y + 9, 16, 16, false)) { save(); Config.save(); mc.gui.setScreen(new ModuleScreen("crosshair")); }
		Ui.spaced(g, "CROSSHAIR EDITOR", x + 32, y + 13, 0xFFFFFFFF);

		int gx = x + 16, gy = y + 48;
		Ui.rect(g, gx - 2, gy - 2, N * CELL + 4, N * CELL + 4, Ui.EDGE);
		for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
			int cx = gx + i * CELL, cy = gy + j * CELL;
			int bg = ((i + j) % 2 == 0) ? 0xFF2A2D32 : 0xFF24272C;
			if (i == 7 || j == 7) bg = ((i + j) % 2 == 0) ? 0xFF30384A : 0xFF2A3242;
			Ui.rect(g, cx, cy, CELL, CELL, bg);
			int v = cells[j * N + i] - '0';
			if (v > 0 && v < HudRenderer.PAL.length) Ui.rect(g, cx + 1, cy + 1, CELL - 2, CELL - 2, HudRenderer.PAL[v]);
			if (down && Ui.hit(mx, my, cx, cy, CELL, CELL)) {
				char want = (char) ('0' + color);
				if (cells[j * N + i] != want) { cells[j * N + i] = want; save(); }
			}
		}
		Ui.text(g, "Style must be \"Custom (drawn)\" to use it.", gx, gy + N * CELL + 8, Ui.DIM);

		int px = gx + N * CELL + 22, py = gy;
		Ui.text(g, "Color", px, py, Ui.DIM);
		for (int i = 0; i < COLOR_NAMES.length; i++) {
			int bx = px + (i % 3) * 78, by = py + 14 + (i / 3) * 24;
			if (button(g, COLOR_NAMES[i], bx, by, 74, 20, color == i)) color = i;
			if (i > 0) Ui.rect(g, bx + 4, by + 14, 66, 3, HudRenderer.PAL[i]);
		}
		int ry = py + 14 + 3 * 24 + 6;
		Ui.text(g, "Presets", px, ry, Ui.DIM);
		for (int i = 0; i < PRESETS.length; i++) {
			if (button(g, PRESETS[i], px + (i % 3) * 78, ry + 14 + (i / 3) * 24, 74, 20, false)) {
				char[] p = preset(i).toCharArray();
				for (int k = 0; k < p.length; k++) cells[k] = p[k] == '1' ? (char) ('0' + Math.max(1, color)) : '0';
				save();
			}
		}
		int cy2 = ry + 14 + 2 * 24 + 4;
		if (button(g, "Clear all", px, cy2, 74, 20, false)) { java.util.Arrays.fill(cells, '0'); save(); }

		int vy = cy2 + 30;
		Ui.text(g, "Preview", px, vy, Ui.DIM);
		Ui.rect(g, px, vy + 12, 56, 56, 0xFF3C5A3A);
		Ui.rect(g, px + 66, vy + 12, 56, 56, 0xFF3C5A3A);
		paint(g, px + 28 - 7, vy + 12 + 28 - 7, 1);
		paint(g, px + 66 + 28 - 22, vy + 12 + 28 - 22, 3);
	}

	private void paint(GuiGraphicsExtractor g, int ox, int oy, int sc) {
		for (int j = 0; j < N; j++) for (int i = 0; i < N; i++) {
			int v = cells[j * N + i] - '0';
			if (v > 0 && v < HudRenderer.PAL.length) g.fill(ox + i * sc, oy + j * sc, ox + (i + 1) * sc, oy + (j + 1) * sc, HudRenderer.PAL[v]);
		}
	}
}
