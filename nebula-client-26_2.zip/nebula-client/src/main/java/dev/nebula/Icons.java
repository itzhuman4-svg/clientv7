package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.resources.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Reads the game's own textures (so resource packs are respected) and turns them into a short list of
 * coloured rectangles that can be drawn with plain fills. Used for the vanilla potion icons and for the
 * golden hunger icons that show your saturation.
 */
final class Icons {
	/** An image as merged pixel runs: {x, y, w, h, argb}. */
	static final class Img {
		final int w;
		final int[][] runs;
		Img(int w, int[][] runs) { this.w = w; this.runs = runs; }
		boolean empty() { return runs.length == 0; }
	}

	private static final Img NONE = new Img(1, new int[0][]);
	private static final Map<String, Img> CACHE = new HashMap<>();

	static void clear() { CACHE.clear(); }

	// ------------------------------------------------------------ loading

	private static BufferedImage read(String ns, String path) {
		try {
			Identifier id = Identifier.fromNamespaceAndPath(ns, path);
			var res = Minecraft.getInstance().getResourceManager().getResource(id);
			if (res.isEmpty()) return null;
			try (InputStream in = res.get().open()) {
				return ImageIO.read(in);
			}
		} catch (Throwable t) {
			return null;
		}
	}

	private static Img build(BufferedImage bi, boolean gold) {
		int step = Math.max(1, Math.max(bi.getWidth(), bi.getHeight()) / 32);
		int w = bi.getWidth() / step, h = bi.getHeight() / step;
		int[][] px = new int[h][w];
		for (int y = 0; y < h; y++) {
			for (int x = 0; x < w; x++) {
				int argb = bi.getRGB(x * step, y * step);
				px[y][x] = ((argb >>> 24) & 255) < 16 ? 0 : gold ? gold(argb) : argb;
			}
		}
		return merge(px, w, h);
	}

	/** Greedy merge: horizontal runs of the same colour, stacked when identical to the row above. */
	private static Img merge(int[][] px, int w, int h) {
		List<int[]> out = new ArrayList<>();
		List<int[]> prev = new ArrayList<>();
		for (int y = 0; y < h; y++) {
			List<int[]> cur = new ArrayList<>();
			int x = 0;
			while (x < w) {
				int c = px[y][x];
				if (c == 0) { x++; continue; }
				int k = x;
				while (k + 1 < w && px[y][k + 1] == c) k++;
				int len = k - x + 1;
				int[] match = null;
				for (int[] p : prev) if (p[0] == x && p[2] == len && p[4] == c) { match = p; break; }
				if (match != null) {
					match[3]++;
					cur.add(match);
				} else {
					int[] r = {x, y, len, 1, c};
					out.add(r);
					cur.add(r);
				}
				x = k + 1;
			}
			prev = cur;
		}
		return new Img(w, out.toArray(new int[0][]));
	}

	// ------------------------------------------------------------ gold recolor

	private static int gold(int argb) {
		int a = argb >>> 24, r = (argb >> 16) & 255, g = (argb >> 8) & 255, b = argb & 255;
		float l = (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
		float t = Math.max(0f, Math.min(1f, (l - 0.05f) / 0.45f));
		int rgb = t < 0.45f
				? Ui.lerp(0xFF4A3000, 0xFFE6AA10, t / 0.45f)
				: Ui.lerp(0xFFE6AA10, 0xFFFFEE70, (t - 0.45f) / 0.55f);
		return (a << 24) | (rgb & 0xFFFFFF);
	}

	/** Hand-made drumstick used only if the game's own hunger texture cannot be read. */
	private static final String[] FALLBACK = {
			".....###.",
			"....#YYY#",
			"...#YYYY#",
			"..#YYYY#.",
			".#YYYY#..",
			"#WYYY#...",
			"#WW##....",
			".#W#.....",
			"..#......"};

	private static Img fallback() {
		int[][] px = new int[9][9];
		for (int y = 0; y < 9; y++)
			for (int x = 0; x < 9; x++)
				px[y][x] = switch (FALLBACK[y].charAt(x)) {
					case '#' -> 0xFF5A3A00;
					case 'Y' -> 0xFFE6AA10;
					case 'W' -> 0xFFFFEE70;
					default -> 0;
				};
		return merge(px, 9, 9);
	}

	// ------------------------------------------------------------ public

	/** Golden full or half hunger icon. */
	static Img goldFood(boolean half) {
		String key = half ? "gold_half" : "gold_full";
		Img img = CACHE.get(key);
		if (img != null) return img;
		BufferedImage bi = read("minecraft", "textures/gui/sprites/hud/" + (half ? "food_half" : "food_full") + ".png");
		img = bi != null ? build(bi, true) : fallback();
		CACHE.put(key, img);
		return img;
	}

	/** The vanilla icon of a potion effect, from its registry name like "minecraft:speed". Empty if not found. */
	static Img effect(String registryName) {
		Img img = CACHE.get(registryName);
		if (img != null) return img;
		int c = registryName.indexOf(':');
		String ns = c >= 0 ? registryName.substring(0, c) : "minecraft";
		String path = c >= 0 ? registryName.substring(c + 1) : registryName;
		BufferedImage bi = read(ns, "textures/gui/sprites/mob_effect/" + path + ".png");
		if (bi == null) bi = read(ns, "textures/mob_effect/" + path + ".png");
		img = bi != null ? build(bi, false) : NONE;
		CACHE.put(registryName, img);
		return img;
	}

	/** Draws an image scaled to size x size pixels at (x, y). */
	static void draw(GuiGraphicsExtractor g, Img img, int x, int y, int size) {
		if (img.empty()) return;
		if (img.w == size) {
			for (int[] r : img.runs) g.fill(x + r[0], y + r[1], x + r[0] + r[2], y + r[1] + r[3], r[4]);
			return;
		}
		var pose = g.pose();
		pose.pushMatrix();
		pose.translate(x, y);
		float s = size / (float) img.w;
		pose.scale(s, s);
		for (int[] r : img.runs) g.fill(r[0], r[1], r[0] + r[2], r[1] + r[3], r[4]);
		pose.popMatrix();
	}

	private Icons() {}
}
