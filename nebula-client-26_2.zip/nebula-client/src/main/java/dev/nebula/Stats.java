package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayDeque;

/** Tracks speed, TPS estimate, playtime, deaths, reach, combo and hit markers. */
final class Stats {
	static double speed;
	static double tps = 20;
	static int combo;
	static double lastReach = -1;
	static int hitTicks, hitMax = 8;

	private static long sessionStart;
	private static double lx, lz;
	private static boolean havePos, wasDead;
	private static int prevHurt, sampleTimer;
	private static long lastHitMs;
	private static final ArrayDeque<double[]> samples = new ArrayDeque<>();

	static long sessionSeconds() { return sessionStart == 0 ? 0 : (System.currentTimeMillis() - sessionStart) / 1000; }

	static void tick(Minecraft mc) {
		LocalPlayer p = mc.player;
		if (p == null || mc.level == null) {
			sessionStart = 0; havePos = false; wasDead = false; samples.clear(); sampleTimer = 0;
			return;
		}
		long now = System.currentTimeMillis();
		if (sessionStart == 0) sessionStart = now;
		Config.I.totalPlaySeconds += 0.05;

		if (havePos) speed += (Math.hypot(p.getX() - lx, p.getZ() - lz) * 20 - speed) * 0.3;
		lx = p.getX(); lz = p.getZ(); havePos = true;

		boolean dead = p.getHealth() <= 0f;
		if (dead && !wasDead) {
			Config.I.deaths++;
			Config.I.lastDeath = (int) Math.floor(p.getX()) + " " + (int) Math.floor(p.getY()) + " " + (int) Math.floor(p.getZ());
			Config.save();
		}
		wasDead = dead;

		if (p.hurtTime > 0 && prevHurt == 0) combo = 0;
		prevHurt = p.hurtTime;
		if (combo > 0 && now - lastHitMs > Modules.m("combo").num("timeout") * 1000) combo = 0;
		if (hitTicks > 0) hitTicks--;

		if (++sampleTimer >= 20) {
			sampleTimer = 0;
			samples.add(new double[]{System.nanoTime() / 1e9, mc.level.getGameTime()});
			while (samples.size() > 16) samples.poll();
			if (samples.size() >= 4) {
				double[] a = samples.peekFirst(), b = samples.peekLast();
				double dt = b[0] - a[0];
				if (dt > 1) tps = Math.max(0, Math.min(20, (b[1] - a[1]) / dt));
			}
		}
	}

	/** Called by Fabric's AttackEntityCallback when YOU attack an entity. */
	static void onAttack(Entity target) {
		Minecraft mc = Minecraft.getInstance();
		if (mc.player == null) return;
		Vec3 eye = mc.player.getEyePosition();
		AABB bb = target.getBoundingBox();
		Vec3 closest = new Vec3(Mth.clamp(eye.x, bb.minX, bb.maxX), Mth.clamp(eye.y, bb.minY, bb.maxY), Mth.clamp(eye.z, bb.minZ, bb.maxZ));
		lastReach = eye.distanceTo(closest);
		if (target instanceof LivingEntity) {
			combo++;
			lastHitMs = System.currentTimeMillis();
			hitMax = Math.max(1, (int) Modules.m("hitindicator").num("duration"));
			hitTicks = hitMax;
		}
	}

	private Stats() {}
}
