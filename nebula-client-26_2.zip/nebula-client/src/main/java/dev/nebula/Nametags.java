package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.phys.Vec3;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

/**
 * Edits the name tag of a player right after the game has prepared it for drawing:
 * - your own name is shown in third person (F5) when "Show my own name" is on
 * - the Nebula logo is put in front of your name, and in front of every other player the presence check says uses Nebula
 * The logo is a glyph of the font nebula:logo (assets/nebula/font/logo.json). Fields of the render state are reached
 * through reflection so a rename in the game only turns this feature off instead of breaking the build.
 */
public final class Nametags {
	private static final String GLYPH = "\uE000";
	private static final String FALLBACK_GLYPH = "\u2726";
	private static Component logo;
	private static String logoText = GLYPH;
	private static final Map<String, Field> FIELDS = new HashMap<>();

	/** Called from the entity renderer mixin. */
	public static void apply(Entity entity, Object state, float partial) {
		try {
			run(entity, state, partial);
		} catch (Throwable t) {
			// never let a cosmetic feature break rendering
		}
	}

	private static void run(Entity entity, Object state, float partial) {
		Modules.Mod m = Modules.m("nametag");
		Minecraft mc = Minecraft.getInstance();
		if (m == null || !m.on() || mc.player == null || state == null) return;
		if (!(entity instanceof AbstractClientPlayer pl)) return;

		boolean self = pl == mc.player;
		Component tag = get(state, "nameTag") instanceof Component c ? c : null;

		if (self) {
			if (!m.flag("own")) {
				if (tag != null) set(state, "nameTag", null);
				return;
			}
			if (tag == null) {
				tag = Modules.on("nickhider") ? Component.literal(NickHider.display(mc)) : pl.getDisplayName();
				if (get(state, "nameTagAttachment") == null) set(state, "nameTagAttachment", attachment(entity, partial));
			}
		}
		if (tag == null) return;

		boolean mark = m.flag("logo") && (self || (m.flag("others") && Presence.has(pl.getUUID())));
		if (mark && !tag.getString().startsWith(logoText)) {
			Component l = logo();
			tag = Component.empty().append(l).append(Component.literal(" ")).append(tag);
		}
		set(state, "nameTag", tag);
	}

	private static Vec3 attachment(Entity e, float partial) {
		Object atts = Compat.invoke(e, "getAttachments");
		Object slot = Compat.enumConst("net.minecraft.world.entity.EntityAttachment", "NAME_TAG");
		if (atts != Compat.FAIL && slot != null) {
			Object v = Compat.invoke(atts, "getNullable", slot, 0, e.getYRot(partial));
			if (v instanceof Vec3 vec) return vec;
		}
		return new Vec3(0, e.getBbHeight() + 0.5, 0);
	}

	// ------------------------------------------------------------ the logo component

	static Component logo() {
		if (logo == null) {
			Style font = fontStyle("logo");
			if (font != null) {
				logoText = GLYPH;
				logo = Component.literal(GLYPH).withStyle(font.withColor(0xFFFFFF));
			} else {
				logoText = FALLBACK_GLYPH;
				logo = Component.literal(FALLBACK_GLYPH).withStyle(Style.EMPTY.withColor(0x55E5FF));
			}
		}
		return logo;
	}

	/** Style that uses the font nebula:<name>. The method takes an Identifier or a FontDescription depending on the game version. */
	static Style fontStyle(String name) {
		try {
			Identifier font = Identifier.fromNamespaceAndPath("nebula", name);
			Object s = Compat.invoke(Style.EMPTY, "withFont", font);
			if (s instanceof Style st) return st;
			Class<?> fd = Class.forName("net.minecraft.network.chat.FontDescription$Resource");
			Object desc = fd.getConstructor(Identifier.class).newInstance(font);
			s = Compat.invoke(Style.EMPTY, "withFont", desc);
			if (s instanceof Style st) return st;
		} catch (Throwable ignored) { }
		return null;
	}

	// ------------------------------------------------------------ reflection helpers (cached)

	private static Field field(Class<?> c, String name) {
		String key = c.getName() + "#" + name;
		if (FIELDS.containsKey(key)) return FIELDS.get(key);
		Field found = null;
		for (Class<?> k = c; k != null && found == null; k = k.getSuperclass()) {
			try {
				found = k.getDeclaredField(name);
				found.setAccessible(true);
			} catch (Throwable ignored) {
				found = null;
			}
		}
		FIELDS.put(key, found);
		return found;
	}

	private static Object get(Object o, String name) {
		try {
			Field f = field(o.getClass(), name);
			return f == null ? null : f.get(o);
		} catch (Throwable t) {
			return null;
		}
	}

	private static void set(Object o, String name, Object v) {
		try {
			Field f = field(o.getClass(), name);
			if (f != null) f.set(o, v);
		} catch (Throwable ignored) { }
	}

	private Nametags() {}
}
