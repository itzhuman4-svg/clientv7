package dev.nebula;

import net.minecraft.client.Minecraft;

import java.lang.management.ManagementFactory;

/** Performance profiles (Potato/Low/Medium/High) and live usage numbers. */
final class Perf {
	static final String[] NAMES = {"POTATO", "LOW", "MEDIUM", "HIGH"};
	static final String[] DESC = {
			"Render distance 4, fast graphics, no AO, minimal particles, no clouds or shadows. Optimizer culls particles past 20 blocks and entities past 32. Cosmetic particles off.",
			"Render distance 8, fast graphics, no AO, fewer particles, no clouds or shadows. Optimizer culls particles past 28 blocks and entities past 48.",
			"Render distance 12, fewer particles, fast clouds, shadows on. Optimizer culls particles past 40 blocks and entities past 72.",
			"Render distance 16, all particles, fancy clouds, full biome blend. Optimizer only trims extreme particle floods."};

	private static final int[] RD = {4, 8, 12, 16}, SD = {5, 6, 8, 10}, BLEND = {0, 1, 3, 5}, MIP = {0, 1, 2, 4};
	private static final String[] PART = {"MINIMAL", "DECREASED", "DECREASED", "ALL"}, CLOUD = {"OFF", "OFF", "FAST", "FANCY"};
	private static final double[] ENT = {0.5, 0.75, 1.0, 1.25};

	static final int[] hist = new int[120];
	static int histPos, histCount;
	static double cpuProc = -1, cpuSys = -1;
	private static int cpuTimer;

	static void tick(Minecraft mc) {
		hist[histPos] = mc.getFps();
		histPos = (histPos + 1) % hist.length;
		histCount = Math.min(hist.length, histCount + 1);
		if (++cpuTimer >= 10) {
			cpuTimer = 0;
			cpuProc = cpu("getProcessCpuLoad");
			cpuSys = cpu("getCpuLoad", "getSystemCpuLoad");
		}
	}

	static int sample(int i) { return hist[Math.floorMod(histPos - histCount + i, hist.length)]; }

	static double avgFps() {
		if (histCount == 0) return 0;
		long sum = 0;
		for (int i = 0; i < histCount; i++) sum += sample(i);
		return sum / (double) histCount;
	}

	/** Average of the slowest 1% of samples. */
	static double lowFps() {
		if (histCount == 0) return 0;
		int[] c = new int[histCount];
		for (int i = 0; i < histCount; i++) c[i] = sample(i);
		java.util.Arrays.sort(c);
		int n = Math.max(1, histCount / 20);
		long sum = 0;
		for (int i = 0; i < n; i++) sum += c[i];
		return sum / (double) n;
	}

	static int maxFps() { int m = 1; for (int i = 0; i < histCount; i++) m = Math.max(m, sample(i)); return m; }

	static long usedMb() { Runtime r = Runtime.getRuntime(); return (r.totalMemory() - r.freeMemory()) / 1048576; }
	static long allocMb() { return Runtime.getRuntime().totalMemory() / 1048576; }
	static long maxMb() { return Runtime.getRuntime().maxMemory() / 1048576; }

	private static Object os(String... names) {
		try {
			Object os = ManagementFactory.getOperatingSystemMXBean();
			Class<?> c = Class.forName("com.sun.management.OperatingSystemMXBean");
			if (!c.isInstance(os)) return null;
			for (String n : names) {
				try { return c.getMethod(n).invoke(os); } catch (NoSuchMethodException ignored) { }
			}
		} catch (Throwable ignored) { }
		return null;
	}

	private static double cpu(String... names) {
		Object v = os(names);
		return v instanceof Double d && d >= 0 ? d : -1;
	}

	static long sysTotalMb() { Object v = os("getTotalMemorySize", "getTotalPhysicalMemorySize"); return v instanceof Long l ? l / 1048576 : -1; }
	static long sysFreeMb() { Object v = os("getFreeMemorySize", "getFreePhysicalMemorySize"); return v instanceof Long l ? l / 1048576 : -1; }

	/** Applies a profile to the video options. Names that don't exist in this version are skipped. */
	static void apply(Minecraft mc, int level) {
		Features.forgetBoost();
		set(mc, "renderDistance", RD[level]);
		set(mc, "simulationDistance", SD[level]);
		set(mc, "particles", PART[level]);
		set(mc, "cloudStatus", CLOUD[level]);
		set(mc, "entityShadows", level >= 2);
		set(mc, "biomeBlendRadius", BLEND[level]);
		set(mc, "entityDistanceScaling", ENT[level]);
		set(mc, "mipmapLevels", MIP[level]);
		if (level <= 1) { set(mc, "enableVsync", false); set(mc, "framerateLimit", 260); }

		// extra options; every name is skipped silently if this version does not have it
		setAny(mc, "graphicsMode", level <= 1 ? "FAST" : "FANCY");
		setAny(mc, "ambientOcclusion", level <= 1 ? new Object[]{Boolean.FALSE, "OFF"} : new Object[]{Boolean.TRUE, "MAX"});
		setAny(mc, "cutoutLeaves", level >= 2);
		setAny(mc, "improvedTransparency", level >= 3);
		setAny(mc, "weatherRadius", new int[]{3, 5, 7, 10}[level]);
		setAny(mc, "maxAnisotropyBit", new int[]{0, 0, 1, 2}[level]);
		setAny(mc, "chunkSectionFadeInTime", level <= 1 ? 0.0 : 0.75);
		setAny(mc, "autosaveIndicator", level >= 2);
		if (level <= 2) setAny(mc, "inactivityFpsLimit", "AFK");
		Optimizer.forget();
		Config.I.perfProfile = level;
		Config.save();
	}

	private static void set(Minecraft mc, String name, Object wanted) { setAny(mc, name, new Object[]{wanted}); }

	/** Sets an option to the first candidate whose type fits (a flag may be a boolean in one version and an enum in another). */
	private static void setAny(Minecraft mc, String name, Object... candidates) {
		if (candidates.length == 1 && candidates[0] instanceof Object[] arr) candidates = arr;
		Object opt = Compat.invoke(mc.options, name);
		if (opt == Compat.FAIL || opt == null) return;
		Object cur = Compat.invoke(opt, "get");
		if (cur == Compat.FAIL || cur == null) return;
		for (Object c : candidates) {
			Object w = Features.convert(c, cur);
			if (w == null) continue;
			if (!w.equals(cur)) Compat.invoke(opt, "set", w);
			return;
		}
	}

	// ------------------------------------------------------------ JVM info (a mod cannot change JVM flags, so we only report)

	static String gcName() {
		try {
			StringBuilder sb = new StringBuilder();
			for (java.lang.management.GarbageCollectorMXBean b : ManagementFactory.getGarbageCollectorMXBeans()) {
				if (sb.length() > 0) sb.append(" + ");
				sb.append(b.getName());
			}
			return sb.toString();
		} catch (Throwable t) {
			return "unknown";
		}
	}

	/** One line telling what to change in the launcher's JVM arguments, based on what the game is running with now. */
	static String jvmTip() {
		long max = maxMb();
		String gc = gcName().toLowerCase();
		if (max < 2500) return "Tip: give the game 3-4 GB of RAM in your launcher (-Xmx4G) to avoid stutter.";
		boolean zgc = gc.contains("zgc") || gc.contains("shenandoah");
		if (!zgc) return "Tip: JVM args -XX:+UseZGC -Xms" + (max / 1024 + 1) + "G -Xmx" + (max / 1024 + 1) + "G cut lag spikes on Java 25.";
		return "JVM setup looks good.";
	}

	private Perf() {}
}
