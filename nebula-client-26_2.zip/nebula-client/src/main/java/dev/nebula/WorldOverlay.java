package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

/** Waypoint beams and coloured hitbox outlines, drawn on top of the world using the real camera. */
final class WorldOverlay {
	static void draw(GuiGraphicsExtractor g, Minecraft mc) {
		boolean wp = Modules.on("waypoints") && !Config.I.waypoints.isEmpty();
		boolean hb = Modules.on("hitbox");
		if (!wp && !hb) return;
		Proj.update(mc);
		if (wp) waypoints(g, mc);
		if (hb) hitboxes(g, mc);
	}

	static void addHere(Minecraft mc) {
		if (mc.player == null) return;
		Config.Waypoint w = new Config.Waypoint("WP" + (Config.I.waypoints.size() + 1), mc.player.getX(), mc.player.getY(), mc.player.getZ());
		w.dim = dimension(mc);
		Config.I.waypoints.add(w);
		Config.save();
	}

	static String dimension(Minecraft mc) { return mc.level == null ? "" : String.valueOf(mc.level.dimension()); }

	private static void waypoints(GuiGraphicsExtractor g, Minecraft mc) {
		Modules.Mod m = Modules.m("waypoints");
		boolean beam = m.flag("beam"), names = m.flag("names");
		int width = (int) m.num("width");
		String dim = dimension(mc);
		int i = 0;
		for (Config.Waypoint w : Config.I.waypoints) {
			int idx = i++;
			if (!w.dim.isEmpty() && !w.dim.equals(dim)) continue;
			int rgb = w.color >= 0 ? w.color : Ui.SWATCH[idx % Ui.SWATCH.length];

			if (beam) {
				double[] base = Proj.cam(w.x, w.y, w.z), top = Proj.cam(w.x, w.y + 320, w.z);
				Proj.line(g, base, top, rgb, 230, 40, width);
				Proj.line(g, Proj.cam(w.x, w.y, w.z), Proj.cam(w.x, w.y + 320, w.z), 0xFFFFFF, 120, 0, Math.max(1, width / 3));
			}
			if (names) {
				double dist = Math.sqrt(Math.pow(w.x - Proj.cx, 2) + Math.pow(w.z - Proj.cz, 2));
				String label = w.name + "  " + (int) dist + "m";
				double[] c = Proj.cam(w.x, w.y + 2, w.z);
				int sx, sy;
				if (c[2] > 0.05) {
					double[] s = Proj.screen(c);
					sx = (int) s[0]; sy = (int) s[1];
				} else {
					sx = c[0] > 0 ? Proj.sw - 8 - Ui.width(label) / 2 : 8 + Ui.width(label) / 2;
					sy = Proj.sh / 2;
				}
				sx = Math.max(Ui.width(label) / 2 + 4, Math.min(Proj.sw - Ui.width(label) / 2 - 4, sx));
				sy = Math.max(12, Math.min(Proj.sh - 24, sy));
				int tw = Ui.width(label);
				g.fill(sx - tw / 2 - 3, sy - 2, sx + tw / 2 + 3, sy + 10, 0xAA000000);
				g.fill(sx - tw / 2 - 3, sy - 2, sx - tw / 2 - 2, sy + 10, 0xFF000000 | rgb);
				Ui.text(g, label, sx - tw / 2, sy, 0xFFFFFFFF);
			}
		}
	}

	private static List<LivingEntity> hbCache = List.of();
	private static long hbTick = Long.MIN_VALUE;
	private static Object hbLevel;

	private static void hitboxes(GuiGraphicsExtractor g, Minecraft mc) {
		Modules.Mod m = Modules.m("hitbox");
		double maxD = m.num("distance"), reach = m.num("reach");
		var p = mc.player;
		Vec3 eye = p.getEyePosition(), look = p.getLookAngle(), end = eye.add(look.scale(reach));
		long gt = mc.level.getGameTime();
		if (gt - hbTick >= 2 || gt < hbTick || hbLevel != mc.level) {
			hbCache = mc.level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(maxD));
			hbTick = gt;
			hbLevel = mc.level;
		}
		List<LivingEntity> list = hbCache;
		int drawn = 0;
		for (LivingEntity e : list) {
			if (e == p || e.isInvisible() || e.isRemoved() || drawn >= 8) continue;
			if (e.distanceTo(p) > maxD || !p.hasLineOfSight(e)) continue;
			AABB bb = e.getBoundingBox();
			boolean canHit = bb.inflate(e.getPickRadius()).clip(eye, end).isPresent();
			int color = canHit ? 0xFF4040 : 0xFFFFFF;
			box(g, bb, color);
			drawn++;
		}
	}

	private static void box(GuiGraphicsExtractor g, AABB b, int rgb) {
		double[][] c = new double[8][];
		int k = 0;
		for (int xi = 0; xi < 2; xi++) for (int yi = 0; yi < 2; yi++) for (int zi = 0; zi < 2; zi++)
			c[k++] = Proj.cam(xi == 0 ? b.minX : b.maxX, yi == 0 ? b.minY : b.maxY, zi == 0 ? b.minZ : b.maxZ);
		int[][] edges = {{0, 1}, {2, 3}, {4, 5}, {6, 7}, {0, 2}, {1, 3}, {4, 6}, {5, 7}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
		for (int[] e : edges) Proj.line(g, c[e[0]], c[e[1]], rgb, 255, 255, 1);
	}

	private WorldOverlay() {}
}
