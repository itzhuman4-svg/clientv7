package dev.nebula;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

/** Immediate-mode screen: draws its own widgets, polls mouse and keyboard, optional blurred background. */
abstract class UiScreen extends Screen {
	protected boolean down, click;
	protected int mx, my;
	protected String focusId;
	private String activeSlider;

	private static final java.util.Map<String, Float> ANIM = new java.util.HashMap<>();
	private long lastNs;
	protected float dt = 0.016f;

	/** Smooth 0..1 hover value for a widget id: eases in over ~150 ms, out over ~220 ms. */
	protected float hv(String id, boolean target) {
		float cur = ANIM.getOrDefault(id, 0f), t = target ? 1f : 0f;
		cur += (t - cur) * (1f - (float) Math.exp(-dt / (target ? 0.05f : 0.08f)));
		if (Math.abs(t - cur) < 0.01f) cur = t;
		if (cur == 0f) ANIM.remove(id); else ANIM.put(id, cur);
		if (ANIM.size() > 600) ANIM.clear();
		return cur;
	}

	private static final int[] KEYS = buildKeys();
	private final boolean[] kPrev = new boolean[512], kEdge = new boolean[512], kDown = new boolean[512];
	private long backSince, backLast;
	private boolean enterPressed;

	protected UiScreen(String title) { super(Component.literal(title)); }

	private static int[] buildKeys() {
		int[] k = new int[2 + 2 + 10 + 26 + 3];
		int n = 0;
		k[n++] = 32; k[n++] = 45; k[n++] = 46; k[n++] = 47; k[n++] = 59;
		for (int c = 48; c <= 57; c++) k[n++] = c;
		for (int c = 65; c <= 90; c++) k[n++] = c;
		k[n++] = 257; k[n++] = 259; k[n++] = 335;
		return k;
	}

	protected boolean blur() { return true; }
	protected int dim() { return 0x50000000; }

	abstract void draw(GuiGraphicsExtractor g, Minecraft mc);

	/** Mouse wheel (no @Override on purpose: harmless if the game's signature differs). */
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		onScroll(scrollY > 0 ? -1 : 1);
		return true;
	}

	protected void onScroll(int dir) {}

	@Override
	public boolean isPauseScreen() { return false; }

	@Override
	public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
		Minecraft mc = Minecraft.getInstance();
		long win = GLFW.glfwGetCurrentContext();
		boolean d = win != 0
				? GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS
				: mc.mouseHandler.isLeftPressed();
		long ns = System.nanoTime();
		dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
		lastNs = ns;
		click = d && !down;
		down = d;
		if (!down) activeSlider = null;
		mx = mouseX;
		my = mouseY;
		if (win != 0) for (int k : KEYS) {
			boolean kd = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
			kEdge[k] = kd && !kPrev[k];
			kPrev[k] = kd;
			kDown[k] = kd;
		}
		enterPressed = kEdge[257] || kEdge[335];

		if (blur()) super.extractRenderState(g, mouseX, mouseY, delta);
		g.fill(0, 0, width, height, dim());
		draw(g, mc);
	}

	// ------------------------------------------------------------ widgets

	/** Plain button (used by the smaller tool screens). */
	protected boolean button(GuiGraphicsExtractor g, String label, int x, int y, int w, int h, boolean active) {
		boolean hover = Ui.hit(mx, my, x, y, w, h);
		float a = hv("b:" + label + x + "," + y, hover);
		Ui.rect(g, x, y, w, h, Ui.lerpArgb(active ? Ui.ACTIVE : Ui.PANEL2, active ? 0xFF2D6FDB : Ui.HOVER, a));
		Ui.border(g, x, y, w, h, Ui.lerpArgb(active ? Ui.BLUE : Ui.EDGE, active ? Ui.BLUE : 0xFF5A606A, a));
		Ui.center(g, Ui.fit(label, w - 6), x + w / 2, y + (h - 8) / 2, active ? 0xFFFFFFFF : Ui.TEXT);
		return click && hover;
	}

	/** Lunar-style button: 0 gray, 1 green, 2 red, 3 blue, 4 dark. Label is drawn letter-spaced. */
	protected boolean gbtn(GuiGraphicsExtractor g, String label, int x, int y, int w, int h, int style) {
		boolean hover = Ui.hit(mx, my, x, y, w, h);
		int[][] pal = {
				{0xFF3A3D43, 0xFF4A4E56, 0xFF5B6068}, {0xFF2E9D5A, 0xFF37B368, 0xFF6CE09A},
				{0xFFB3294A, 0xFFC73559, 0xFFE8708A}, {0xFF2F6FE0, 0xFF4585F5, 0xFF7FB0FF}, {0xFF2C2F34, 0xFF383C42, 0xFF42474F}};
		int[] c = pal[style];
		float a = hv("g:" + label + x + "," + y, hover);
		Ui.rect(g, x, y, w, h, Ui.lerpArgb(c[0], c[1], a));
		Ui.border(g, x, y, w, h, Ui.lerpArgb(c[2], 0xFFFFFFFF, a * 0.35f));
		String t = Ui.spacedWidth(label) > w - 6 ? Ui.fit(label, w - 6) : label;
		if (t == label) Ui.spacedCenter(g, t, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
		else Ui.center(g, t, x + w / 2, y + (h - 8) / 2, 0xFFFFFFFF);
		return click && hover;
	}

	protected double slider(GuiGraphicsExtractor g, String id, int x, int y, int w, int h, double val, double min, double max, double step) {
		boolean hover = Ui.hit(mx, my, x - 3, y, w + 6, h);
		if (click && hover) activeSlider = id;
		if (id.equals(activeSlider)) {
			double t = Math.max(0, Math.min(1, (mx - x) / (double) w));
			double v = min + t * (max - min);
			if (step > 0) v = Math.round(v / step) * step;
			val = Math.max(min, Math.min(max, v));
		}
		double t = (val - min) / (max - min);
		int ky = y + h / 2;
		Ui.rect(g, x, ky - 2, w, 4, 0xFF1B1D21);
		Ui.border(g, x, ky - 2, w, 4, Ui.EDGE);
		int fw = (int) (w * t);
		Ui.rect(g, x + 1, ky - 1, Math.max(0, fw - 1), 2, Ui.BLUE);
		Ui.rect(g, x + fw - 2, ky - 6, 4, 12, hover || id.equals(activeSlider) ? Ui.CYAN : 0xFFFFFFFF);
		return val;
	}

	private static char charFor(int k, boolean shift) {
		if (k >= 65 && k <= 90) return shift ? (char) k : (char) (k + 32);
		if (k >= 48 && k <= 57) return shift ? ")!@#$%^&*(".charAt(k - 48) : (char) k;
		if (k == 32) return ' ';
		if (k == 45) return shift ? '_' : '-';
		if (k == 46) return '.';
		if (k == 47) return '/';
		if (k == 59) return shift ? ':' : ';';
		return 0;
	}

	/** Click-to-focus text box. Returns the (possibly edited) value. Enter or clicking away ends editing. */
	protected String textField(GuiGraphicsExtractor g, String id, int x, int y, int w, int h, String val, int max, String hint) {
		boolean hover = Ui.hit(mx, my, x, y, w, h);
		if (click) {
			if (hover) focusId = id;
			else if (id.equals(focusId)) focusId = null;
		}
		boolean foc = id.equals(focusId);
		if (foc) {
			long win = GLFW.glfwGetCurrentContext();
			boolean shift = win != 0 && (GLFW.glfwGetKey(win, 340) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, 344) == GLFW.GLFW_PRESS);
			boolean ctrl = win != 0 && (GLFW.glfwGetKey(win, 341) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(win, 345) == GLFW.GLFW_PRESS);
			if (ctrl) {
				if (kEdge[86]) {
					Object clip = Compat.invoke(Minecraft.getInstance().keyboardHandler, "getClipboard");
					if (clip instanceof String cs)
						for (int i = 0; i < cs.length() && val.length() < max; i++) {
							char ch = cs.charAt(i);
							if (ch >= 32 && ch < 127) val += ch;
						}
				}
			} else {
				for (int k : KEYS) {
					if (!kEdge[k]) continue;
					char c = charFor(k, shift);
					if (c != 0 && val.length() < max) val += c;
				}
			}
			long now = System.currentTimeMillis();
			if (kEdge[259]) { backSince = now; backLast = now; if (!val.isEmpty()) val = val.substring(0, val.length() - 1); }
			else if (kDown[259] && now - backSince > 350 && now - backLast > 45) {
				backLast = now;
				if (!val.isEmpty()) val = val.substring(0, val.length() - 1);
			}
			if (enterPressed) focusId = null;
		}
		Ui.rect(g, x, y, w, h, 0xFF1B1D21);
		Ui.border(g, x, y, w, h, foc ? Ui.BLUE : hover ? 0xFF5A606A : Ui.EDGE);
		if (val.isEmpty() && !foc) Ui.text(g, hint, x + 4, y + (h - 8) / 2, 0xFF6C727C);
		else {
			String shown = Ui.fit(val, w - 10);
			Ui.text(g, shown, x + 4, y + (h - 8) / 2, 0xFFFFFFFF);
			if (foc && (System.currentTimeMillis() / 500) % 2 == 0) Ui.rect(g, x + 4 + Ui.width(shown), y + 2, 1, h - 4, 0xFFFFFFFF);
		}
		return val;
	}

	@Override
	public void removed() { Config.save(); }
}
