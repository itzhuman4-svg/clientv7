package dev.nebula;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Saved to .minecraft/config/nebula.json */
public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("nebula.json");
	public static Config I = new Config();

	/** Per-HUD-element layout. x/y are fractions of the screen (null = automatic default). */
	public static class P {
		public boolean bg = true;
		public float scale = 1f;
		public Double x, y;
	}

	public static class Waypoint {
		public String name = "";
		public double x, y, z;
		public String dim = "";
		public int color = -1; // -1 = automatic
		public Waypoint() {}
		public Waypoint(String n, double x, double y, double z) { name = n; this.x = x; this.y = y; this.z = z; }
	}

	/** A saved set of settings. Waypoints, playtime and deaths are shared by all profiles. */
	public static class Profile {
		public Map<String, Boolean> flags = new HashMap<>();
		public Map<String, Double> nums = new HashMap<>();
		public Map<String, P> panels = new HashMap<>();
		public boolean allBg = true;
		public String cape = "none", wings = "none", aura = "none", fists = "none";
		public String customCrosshair = "";
	}

	public Map<String, Profile> profiles = new LinkedHashMap<>();
	public String activeProfile = "Default";

	public Map<String, P> panels = new HashMap<>();
	public Map<String, Boolean> flags = new HashMap<>();
	public Map<String, Double> nums = new HashMap<>();
	public boolean allBg = true;

	public List<Waypoint> waypoints = new ArrayList<>();
	public int perfProfile = -1; // 0 potato, 1 low, 2 medium, 3 high
	public double totalPlaySeconds = 0;
	public int deaths = 0;
	public String lastDeath = "";

	public String customCrosshair = "";

	/** Optional server that tells which players use Nebula (empty = nothing is ever sent). */
	public String presenceUrl = "";

	public String cape = "none", wings = "none", aura = "none", fists = "none";

	// ------------------------------------------------------------ profiles

	private static <T> T copy(T o, Class<T> c) { return GSON.fromJson(GSON.toJson(o), c); }

	public Profile snapshot() {
		Profile p = new Profile();
		p.flags = flags; p.nums = nums; p.panels = panels; p.allBg = allBg;
		p.cape = cape; p.wings = wings; p.aura = aura; p.fists = fists; p.customCrosshair = customCrosshair;
		return copy(p, Profile.class);
	}

	public void apply(Profile src) {
		Profile c = copy(src, Profile.class);
		flags = c.flags; nums = c.nums; panels = c.panels; allBg = c.allBg;
		cape = c.cape; wings = c.wings; aura = c.aura; fists = c.fists; customCrosshair = c.customCrosshair;
	}

	public void ensureDefault() {
		if (profiles.isEmpty()) { profiles.put("Default", snapshot()); activeProfile = "Default"; }
		else if (!profiles.containsKey(activeProfile)) activeProfile = profiles.keySet().iterator().next();
	}

	public void switchTo(String name) {
		if (!profiles.containsKey(name) || name.equals(activeProfile)) return;
		profiles.put(activeProfile, snapshot());
		apply(profiles.get(name));
		activeProfile = name;
		save();
	}

	private String unique(String base) {
		String n = base;
		for (int i = 2; profiles.containsKey(n); i++) n = base + " " + i;
		return n;
	}

	public void saveAsNew() {
		profiles.put(activeProfile, snapshot());
		String n = unique("Profile");
		profiles.put(n, snapshot());
		activeProfile = n;
		save();
	}

	public void rename(String old, String neu) {
		neu = neu.trim();
		if (neu.isEmpty() || neu.equals(old) || profiles.containsKey(neu)) return;
		Map<String, Profile> m = new LinkedHashMap<>();
		for (Map.Entry<String, Profile> e : profiles.entrySet()) m.put(e.getKey().equals(old) ? neu : e.getKey(), e.getValue());
		profiles = m;
		if (activeProfile.equals(old)) activeProfile = neu;
		save();
	}

	public void delete(String name) {
		if (profiles.size() <= 1 || !profiles.containsKey(name)) return;
		profiles.remove(name);
		if (activeProfile.equals(name)) {
			activeProfile = profiles.keySet().iterator().next();
			apply(profiles.get(activeProfile));
		}
		save();
	}

	public void resetCurrent() { apply(new Profile()); save(); }

	public String export() {
		return "NEBULA1:" + Base64.getEncoder().encodeToString(GSON.toJson(snapshot()).getBytes(StandardCharsets.UTF_8));
	}

	public boolean importFrom(String text) {
		try {
			if (text == null || !text.trim().startsWith("NEBULA1:")) return false;
			String json = new String(Base64.getDecoder().decode(text.trim().substring(8)), StandardCharsets.UTF_8);
			Profile p = GSON.fromJson(json, Profile.class);
			if (p == null) return false;
			profiles.put(unique("Imported"), p);
			save();
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public P p(String id) { return panels.computeIfAbsent(id, k -> new P()); }
	public boolean flag(String k, boolean d) { return flags.getOrDefault(k, d); }
	public double num(String k, double d) { return nums.getOrDefault(k, d); }

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				Config c = GSON.fromJson(Files.readString(FILE), Config.class);
				if (c != null) I = c;
				I.ensureDefault();
			}
		} catch (Exception e) {
			NebulaClient.LOG.warn("Could not read config, using defaults", e);
		}
	}

	public static void save() {
		try {
			if (I.profiles.containsKey(I.activeProfile)) I.profiles.put(I.activeProfile, I.snapshot());
			Files.writeString(FILE, GSON.toJson(I));
		} catch (Exception e) {
			NebulaClient.LOG.warn("Could not save config", e);
		}
	}
}
