package dev.nebula;

import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.Style;

import java.util.Optional;

/** Replaces your username in game/system messages (join, leave, death, etc.). */
final class NickHider {
	private static final String[] ALIASES = {"Player", "Hidden", "Nebula", "Orbitive", "Anonymous", "Steve"};

	static void register() {
		ClientReceiveMessageEvents.MODIFY_GAME.register((message, overlay) -> modify(message));
	}

	/** Your name as it should be shown (alias when Nick Hider is on). */
	static String display(Minecraft mc) {
		String real = mc.getUser().getName();
		Modules.Mod m = Modules.m("nickhider");
		return m != null && m.on() ? ALIASES[Math.floorMod(m.opt("alias"), ALIASES.length)] : real;
	}

	private static Component modify(Component c) {
		Modules.Mod m = Modules.m("nickhider");
		if (m == null || !m.on()) return c;
		String real = Minecraft.getInstance().getUser().getName();
		if (real == null || real.isEmpty() || !c.getString().contains(real)) return c;
		String alias = ALIASES[Math.floorMod(m.opt("alias"), ALIASES.length)];
		MutableComponent out = Component.empty();
		c.<Object>visit((style, text) -> {
			out.append(Component.literal(text.replace(real, alias)).withStyle(style));
			return Optional.empty();
		}, Style.EMPTY);
		return out;
	}

	private NickHider() {}
}
